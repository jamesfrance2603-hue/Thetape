#!/usr/bin/env python3
"""MarketPage command line.

  python run.py daily|weekly|radar|recap [--demo] [--date YYYY-MM-DD]
      Build data -> write script -> compliance check -> render -> send for approval (or auto-publish).
  python run.py alert --demo         Render the sample breaking-news alert.
  python run.py watch                Breaking news and big-mover watcher (keep running on the server).
  python run.py reaction|sector|dividends|rotation [--demo]   The newer shows.
  python run.py broll [tag]          Generate the retro footage library with Grok Imagine (once).
  python run.py approve <run_id>     Publish a reviewed draft.
  python run.py listen               Run the Telegram approval listener (keep running on the server).
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import date, datetime
from pathlib import Path

from marketpage import compliance, publish, render, sample, writer
from marketpage.config import ROOT, load_config

OUT = ROOT / "out"
STATE = ROOT / "state"


def _with_recap_implied(payload: dict) -> dict:
    """Add the implied move saved by Sunday's weekly run, so the recap can score each report."""
    f = STATE / f"weekly_{payload['week_of']}.json"
    if f.exists():
        implied = {r["symbol"]: (r.get("implied") or {}).get("implied_move_pct") for r in json.loads(f.read_text())}
        for r in payload["earnings_results"]:
            r.setdefault("implied_move_pct", implied.get(r["symbol"]))
    return payload


def build(show: str, demo: bool, day: date, cfg: dict, payload: dict | None = None) -> str:
    if payload is None and demo:
        payload = sample.SAMPLES[show](day)
    elif payload is None:
        from marketpage.datasets import BUILDERS
        payload = BUILDERS[show](cfg, day)
    if show == "recap" and not demo:
        payload = _with_recap_implied(payload)
    if show == "weekly" and not demo:
        STATE.mkdir(exist_ok=True)
        (STATE / f"weekly_{payload['week_start']}.json").write_text(json.dumps(payload["earnings"], default=str))

    run_id = f"{day:%Y%m%d}-{show}" + (f"-{datetime.utcnow():%H%M}-{payload.get('symbol') or 'news'}" if show == "alert" else "") \
        + ("-demo" if demo else "")
    out = OUT / run_id
    out.mkdir(parents=True, exist_ok=True)
    (out / "payload.json").write_text(json.dumps(payload, indent=2, default=str))

    script = writer.write(payload, cfg)
    report = compliance.check(script, payload)
    (out / "script.json").write_text(json.dumps(script, indent=2))
    (out / "compliance.json").write_text(json.dumps(report, indent=2))

    video = render.render(script, payload, cfg, out)
    print(f"[{run_id}] rendered {video}")
    print(f"[{run_id}] compliance: {'clean' if report['clean'] else report}")

    if demo:
        print(f"[{run_id}] demo run: sample data, never published")
    elif cfg["publish"]["auto_publish"] and report["clean"] and not script.get("writer_error"):
        approve(run_id, cfg)
    else:
        publish.send_for_review(run_id, video, script, report)
        print(f"[{run_id}] sent for approval")
    return run_id


def approve(run_id: str, cfg: dict) -> list[str]:
    out = OUT / run_id
    if run_id.endswith("-demo"):
        raise SystemExit("Demo runs use sample data and cannot be published.")
    script = json.loads((out / "script.json").read_text())
    video = out / "video.mp4"
    links = []
    if cfg["publish"]["youtube"]:
        links.append(publish.youtube_upload(video, script, cfg))
    if cfg["publish"]["tiktok"]:
        links.append(publish.tiktok_upload(video, script, cfg))
    (out / "published.json").write_text(json.dumps({"at": datetime.utcnow().isoformat(), "links": links}))
    publish.notify(f"Posted {run_id}:\n" + "\n".join(links))
    return links


def watch(cfg: dict):
    """Breaking news / big mover loop. Each alert goes to Telegram like any other draft."""
    import time
    from zoneinfo import ZoneInfo

    from marketpage import alerts

    a = cfg["alerts"]
    print("Watching for breaking news and big moves. Ctrl+C to stop.")
    while True:
        now_uk = datetime.now(ZoneInfo("Europe/London"))
        if alerts.in_window(now_uk, a):
            try:
                for payload in alerts.scan(cfg):
                    build("alert", False, now_uk.date(), cfg, payload=payload)
            except Exception as exc:
                print("watch error:", exc)
        time.sleep(a["check_every_minutes"] * 60)


def listen(cfg: dict):
    offset = None
    print("Listening for /approve and /reject on Telegram. Ctrl+C to stop.")
    while True:
        cmds, offset = publish.poll_commands(offset)
        for action, run_id in cmds:
            try:
                if action == "approve":
                    approve(run_id, cfg)
                else:
                    (OUT / run_id / "rejected").touch()
                    publish.notify(f"Rejected {run_id}, nothing posted.")
            except Exception as exc:
                publish.notify(f"{action} {run_id} failed: {exc}")


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("command", choices=["daily", "weekly", "radar", "recap", "alert", "reaction", "sector", "dividends",
                                       "rotation", "approve", "listen", "watch", "broll"])
    ap.add_argument("run_id", nargs="?")
    ap.add_argument("--demo", action="store_true", help="use sample data, no API keys needed")
    ap.add_argument("--date", default=None)
    ap.add_argument("--config", default=None)
    a = ap.parse_args(argv)
    cfg = load_config(a.config)
    day = date.fromisoformat(a.date) if a.date else date.today()
    if a.command == "approve":
        if not a.run_id:
            sys.exit("approve needs a run_id")
        print(approve(a.run_id, cfg))
    elif a.command == "listen":
        listen(cfg)
    elif a.command == "watch":
        watch(cfg)
    elif a.command == "broll":
        from marketpage import broll
        broll.generate_library(cfg, only=a.run_id)
    elif a.command == "dividends" and not a.demo and cfg["dividends"].get("cadence") == "fortnightly" \
            and day.isocalendar()[1] % 2:
        print("Dividend scorecard runs fortnightly; skipping this week.")
    elif a.command == "alert" and not a.demo:
        sys.exit("Live alerts come from `python run.py watch`; use `alert --demo` to preview.")
    else:
        build(a.command, a.demo, day, cfg)


if __name__ == "__main__":
    main()
