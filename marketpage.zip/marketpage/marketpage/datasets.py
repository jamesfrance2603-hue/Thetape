"""Build the data payload for each show. Every number a script may say comes from here."""
from __future__ import annotations

from datetime import date, timedelta

from . import analytics as A
from .config import load_universe
from .providers import Finnhub, Tradier, econ_calendar, grok_x_search, rss_news


def _implied_for(tr: Tradier, ev: dict, spot: float) -> dict | None:
    expiry = A.pick_event_expiry(tr.expirations(ev["symbol"]), ev["date"], ev["session"])
    if not expiry:
        return None
    st = A.atm_straddle(tr.chain(ev["symbol"], expiry), spot)
    return {**st, "expiry": expiry} if st else None


def _history_for(fh: Finnhub, tr: Tradier, symbol: str, n: int, today: date) -> dict:
    past = fh.earnings(today - timedelta(days=int(n * 95)), today - timedelta(days=1), symbol=symbol)
    past = sorted(past, key=lambda r: r["date"])[-n:]
    if not past:
        return {"avg_move_pct": None, "reports": 0}
    closes = tr.closes(symbol, date.fromisoformat(past[0]["date"]) - timedelta(days=7), today)
    reactions = [A.earnings_reaction_pct(closes, p["date"], p["session"]) for p in past]
    return {"avg_move_pct": A.average_move(reactions), "reports": len([r for r in reactions if r is not None]),
            "last_moves_pct": [r for r in reactions if r is not None][-4:]}


def earnings_board(cfg: dict, start: date, end: date, max_names: int, today: date) -> list[dict]:
    p, e = cfg["providers"], cfg["earnings"]
    fh, tr = Finnhub(p["finnhub_base"]), Tradier(p["tradier_base"])
    universe = set(load_universe(cfg))
    events = [ev for ev in fh.earnings(start, end) if ev["symbol"] in universe]
    for ev in events:
        ev["market_cap"] = fh.market_cap(ev["symbol"])
    events = sorted(events, key=lambda ev: -(ev["market_cap"] or 0))[:max_names]
    quotes = tr.quotes([ev["symbol"] for ev in events]) if events else {}
    board = []
    for ev in events:
        spot = (quotes.get(ev["symbol"]) or {}).get("last")
        if not spot:
            continue
        implied = _implied_for(tr, ev, spot)
        hist = _history_for(fh, tr, ev["symbol"], e["history_reports"], today)
        verdict = A.move_verdict(implied and implied["implied_move_pct"], hist["avg_move_pct"],
                                 e["rich_ratio"], e["cheap_ratio"])
        board.append({**ev, "spot": spot, "implied": implied, "history": hist, **verdict,
                      "move_usd": round(spot * implied["implied_move_pct"] / 100, 2) if implied else None})
    return board


def daily_payload(cfg: dict, today: date) -> dict:
    p, m = cfg["providers"], cfg["market"]
    tr = Tradier(p["tradier_base"])
    news = rss_news(cfg["news"]["rss"], cfg["news"]["lookback_hours"], cfg["news"]["max_items"])
    try:
        news += Finnhub(p["finnhub_base"]).news()[:15]
    except Exception:
        pass
    board = earnings_board(cfg, today, today + timedelta(days=0), cfg["earnings"]["max_names_daily"], today)
    save_implied(board, today)  # the reaction show compares tomorrow's move with this
    return {
        "show": "daily", "date": today.isoformat(),
        "indices": tr.quotes(m["index_symbols"] + [m["vol_symbol"]]),
        "economic_calendar": econ_calendar(p["econ_calendar_url"], today, today, m["econ_countries"], m["econ_min_impact"]),
        "earnings_today": board,
        "news": news,
        "x_chatter": grok_x_search("What are US stock market traders on X focused on this morning?",
                                   cfg["writer"]["xai_model"], hours=12) if cfg["writer"].get("x_context_daily") else {},
    }


def weekly_payload(cfg: dict, today: date) -> dict:
    start, end = A.next_week_range(today)
    m = cfg["market"]
    return {
        "show": "weekly", "week_start": start.isoformat(), "week_end": end.isoformat(),
        "earnings": earnings_board(cfg, start, end, cfg["earnings"]["max_names_weekly"], today),
        "economic_calendar": econ_calendar(cfg["providers"]["econ_calendar_url"], start, end,
                                           m["econ_countries"], m["econ_min_impact"]),
    }


def radar_payload(cfg: dict, today: date) -> dict:
    o = cfg["options_radar"]
    tr = Tradier(cfg["providers"]["tradier_base"])
    syms = load_universe(cfg, "options_radar")
    quotes = tr.quotes(syms)
    hits = []
    for s in syms:
        spot = (quotes.get(s) or {}).get("last")
        if not spot:
            continue
        for e in tr.expirations(s):
            if (date.fromisoformat(e) - today).days > o["max_days_to_expiry"]:
                break
            hits += A.unusual_activity(tr.chain(s, e), spot, e, today, o["min_volume"],
                                       o["min_vol_oi_ratio"], o["min_premium_usd"])
    hits = sorted(hits, key=lambda h: -h["premium_usd"])
    top, seen = [], set()
    for h in hits:  # one contract per stock keeps the video varied
        if h["symbol"] not in seen:
            seen.add(h["symbol"])
            top.append(h)
        if len(top) == o["top_n"]:
            break
    return {"show": "radar", "date": today.isoformat(), "unusual": top}


def recap_payload(cfg: dict, today: date) -> dict:
    """Friday recap: index moves for the week and how reporters did against their implied move."""
    p, m = cfg["providers"], cfg["market"]
    tr, fh = Tradier(p["tradier_base"]), Finnhub(p["finnhub_base"])
    monday = today - timedelta(days=today.weekday())
    week_moves = {}
    for s in m["index_symbols"]:
        c = tr.closes(s, monday - timedelta(days=5), today)
        days = sorted(c)
        prior = [d for d in days if d < monday.isoformat()]
        if prior and days:
            week_moves[s] = round((c[days[-1]] / c[prior[-1]] - 1) * 100, 2)
    universe = set(load_universe(cfg))
    reported = [ev for ev in fh.earnings(monday, today) if ev["symbol"] in universe]
    results = []
    for ev in reported[:12]:
        c = tr.closes(ev["symbol"], date.fromisoformat(ev["date"]) - timedelta(days=5), today)
        move = A.earnings_reaction_pct(c, ev["date"], ev["session"])
        if move is not None:
            results.append({**ev, "actual_move_pct": move})
    return {"show": "recap", "week_of": monday.isoformat(), "index_week_pct": week_moves,
            "earnings_results": sorted(results, key=lambda r: -r["actual_move_pct"])[:5]}


BUILDERS = {"daily": daily_payload, "weekly": weekly_payload, "radar": radar_payload, "recap": recap_payload}


# ---------------------------------------------------------------- new shows

def _implied_history(days: int = 10) -> dict[str, float]:
    """Implied moves saved by earlier daily and weekly runs, newest wins."""
    import json
    from .config import ROOT
    out = {}
    for f in sorted((ROOT / "state").glob("implied_*.json")) + sorted((ROOT / "state").glob("weekly_*.json")):
        try:
            for r in json.loads(f.read_text()):
                v = (r.get("implied") or {}).get("implied_move_pct")
                if v:
                    out[r["symbol"]] = v
        except Exception:
            pass
    return out


def save_implied(board: list[dict], day: date):
    import json
    from .config import ROOT
    (ROOT / "state").mkdir(exist_ok=True)
    (ROOT / "state" / f"implied_{day.isoformat()}.json").write_text(json.dumps(board, default=str))


def reaction_payload(cfg: dict, today: date) -> dict:
    """Last session's reporters: results vs estimates and the share move vs the implied move."""
    p = cfg["providers"]
    fh, tr = Finnhub(p["finnhub_base"]), Tradier(p["tradier_base"])
    universe = set(load_universe(cfg))
    prev = today - timedelta(days=3 if today.weekday() == 0 else 1)
    events = [e for e in fh.earnings(prev, today) if e["symbol"] in universe and
              ((e["date"] == prev.isoformat() and e["session"] == "amc") or
               (e["date"] == today.isoformat() and e["session"] == "bmo"))]
    events = [e for e in events if e.get("eps_actual") is not None]
    implied = _implied_history()
    quotes = tr.quotes([e["symbol"] for e in events]) if events else {}
    rows = []
    for e in events:
        q = quotes.get(e["symbol"]) or {}
        eps_s = (e["eps_actual"] / e["eps_estimate"] - 1) * 100 if e.get("eps_estimate") and e["eps_estimate"] > 0 else None
        rev_s = (e["revenue_actual"] / e["revenue_estimate"] - 1) * 100 if e.get("revenue_actual") and e.get("revenue_estimate") else None
        imp = implied.get(e["symbol"])
        mv = q.get("change_pct")
        rows.append({**e, "spot": q.get("last"), "move_pct": mv, "implied_move_pct": imp,
                     "eps_surprise_pct": round(eps_s, 1) if eps_s is not None else None,
                     "rev_surprise_pct": round(rev_s, 1) if rev_s is not None else None,
                     "move_vs_implied": round(abs(mv) / imp, 2) if mv is not None and imp else None,
                     "actual_move_pct": abs(mv) if mv is not None else None})
    rows.sort(key=lambda r: -(r.get("move_vs_implied") or abs(r.get("move_pct") or 0) / 10))
    return {"show": "reaction", "date": today.isoformat(), "results": rows[:6]}


def sector_payload(cfg: dict, today: date) -> dict:
    from .fundamentals import sector_health
    sectors = cfg["sectors"]
    names = list(sectors)
    name = names[today.isocalendar()[1] % len(names)]  # rotates one sector per week
    return {"show": "sector", "date": today.isoformat(),
            **sector_health(name, sectors[name], cfg["valuation"]["history_years"])}


def dividends_payload(cfg: dict, today: date) -> dict:
    from .fundamentals import dividend_profile
    rows = []
    for s in cfg["dividends"]["kings"]:
        try:
            rows.append(dividend_profile(s))
        except Exception as exc:
            print("dividend profile failed", s, exc)
    rows = [r for r in rows if r.get("cover_score") is not None and r.get("yield_pct")]
    rows.sort(key=lambda r: -r["cover_score"])
    return {"show": "dividends", "date": today.isoformat(), "universe_size": len(rows),
            "top": rows[:5], "weakest": rows[-2:][::-1]}


def rotation_payload(cfg: dict, today: date) -> dict:
    from .fundamentals import rotation
    tr = Tradier(cfg["providers"]["tradier_base"])
    r = cfg["rotation"]
    return {"show": "rotation", "date": today.isoformat(), **rotation(tr, r["etfs"], r["benchmark"], today)}


BUILDERS.update({"reaction": reaction_payload, "sector": sector_payload,
                 "dividends": dividends_payload, "rotation": rotation_payload})
