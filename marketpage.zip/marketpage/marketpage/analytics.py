"""Pure calculations: implied moves, historical earnings moves, unusual options activity.

No network calls here, so everything is unit-testable (see tests/test_analytics.py).
"""
from __future__ import annotations

from datetime import date, timedelta
from statistics import mean


def _mid(opt: dict) -> float | None:
    bid, ask, last = opt.get("bid"), opt.get("ask"), opt.get("last")
    if bid and ask and ask >= bid > 0:
        return (bid + ask) / 2
    return last or None


def pick_event_expiry(expiries: list[str], report_date: str, session: str) -> str | None:
    """First expiry that still holds the earnings reaction.

    bmo (before open): an expiry on the report day already includes the move.
    amc (after close) or unknown: need an expiry strictly after the report day.
    """
    d = date.fromisoformat(report_date)
    for e in sorted(expiries):
        ed = date.fromisoformat(e)
        if (session == "bmo" and ed >= d) or ed > d:
            return e
    return None


def atm_straddle(chain: list[dict], spot: float) -> dict | None:
    """At-the-money straddle from one expiry's chain (Tradier option dicts)."""
    strikes = sorted({o["strike"] for o in chain})
    if not strikes:
        return None
    k = min(strikes, key=lambda s: abs(s - spot))
    call = next((o for o in chain if o["strike"] == k and o["option_type"] == "call"), None)
    put = next((o for o in chain if o["strike"] == k and o["option_type"] == "put"), None)
    if not call or not put:
        return None
    c, p = _mid(call), _mid(put)
    if c is None or p is None:
        return None
    straddle = c + p
    return {"strike": k, "call_mid": round(c, 2), "put_mid": round(p, 2),
            "straddle": round(straddle, 2), "implied_move_pct": round(100 * straddle / spot, 1)}


def earnings_reaction_pct(closes: dict[str, float], report_date: str, session: str) -> float | None:
    """Absolute close-to-close % move attributable to one report.

    bmo: previous trading day's close -> report day close.
    amc: report day close -> next trading day's close.
    `closes` maps ISO date -> close.
    """
    days = sorted(closes)
    if report_date not in closes:
        return None
    i = days.index(report_date)
    if session == "bmo":
        if i == 0:
            return None
        before, after = closes[days[i - 1]], closes[days[i]]
    else:
        if i + 1 >= len(days):
            return None
        before, after = closes[days[i]], closes[days[i + 1]]
    return round(abs(after / before - 1) * 100, 1)


def average_move(reactions: list[float | None]) -> float | None:
    vals = [r for r in reactions if r is not None]
    return round(mean(vals), 1) if vals else None


def move_verdict(implied: float | None, hist: float | None, rich: float, cheap: float) -> dict:
    if not implied or not hist:
        return {"ratio": None, "verdict": "no history"}
    ratio = round(implied / hist, 2)
    verdict = "rich" if ratio >= rich else "cheap" if ratio <= cheap else "in line"
    return {"ratio": ratio, "verdict": verdict}


def unusual_activity(chain: list[dict], spot: float, expiry: str, today: date,
                     min_volume: int, min_ratio: float, min_premium: float) -> list[dict]:
    """Contracts trading far above their open interest with large premium."""
    out = []
    for o in chain:
        vol, oi = o.get("volume") or 0, o.get("open_interest") or 0
        mid = _mid(o)
        if not mid or vol < min_volume:
            continue
        ratio = vol / max(oi, 1)
        premium = vol * mid * 100
        if ratio < min_ratio or premium < min_premium:
            continue
        otm_pct = (o["strike"] / spot - 1) * 100
        out.append({
            "symbol": o.get("underlying"), "option_type": o["option_type"], "strike": o["strike"],
            "expiry": expiry, "dte": (date.fromisoformat(expiry) - today).days,
            "volume": vol, "open_interest": oi, "vol_oi": round(ratio, 1),
            "premium_usd": round(premium), "mid": round(mid, 2),
            "otm_pct": round(otm_pct, 1), "spot": spot,
            # What the trade needs by expiry to break even (simple, ignores IV changes)
            "breakeven": round(o["strike"] + mid if o["option_type"] == "call" else o["strike"] - mid, 2),
        })
    return sorted(out, key=lambda x: -x["premium_usd"])


def next_week_range(today: date) -> tuple[date, date]:
    """Monday to Friday of the coming week (run on Sunday or any day)."""
    monday = today + timedelta(days=(7 - today.weekday()) % 7 or 7)
    return monday, monday + timedelta(days=4)
