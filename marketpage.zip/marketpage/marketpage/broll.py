"""Retro b-roll: a small library of AI-generated 80s/90s Wall Street clips, made once with Grok Imagine.

`python run.py broll` creates assets/broll/<tag>.mp4 for every prompt in config.yaml (skips ones that exist).
Videos use grok-imagine-video; if that fails, a still from grok-imagine-image is animated with a slow zoom.
The renderer then plays a clip, dimmed and tinted, behind the hook and the outro of each video.
Cost: about $0.08 per second of 480p video, so 10 clips x 6 s is roughly $5, once.
"""
from __future__ import annotations

import random
import subprocess
import time
from pathlib import Path

import requests

from .config import ROOT, secret

# which footage suits which show (first tag that exists is used; later tags are fallbacks)
SHOW_TAGS = {
    "daily": ["street", "subway", "newsstand", "skyline", "screens"],
    "weekly": ["screens", "tape", "boardroom", "desk"],
    "radar": ["desk", "floor", "screens"],
    "recap": ["taxi", "skyline", "tape", "street"],
    "reaction": ["floor", "boardroom", "screens"],
    "sector": ["chips", "boardroom", "elevator"],
    "dividends": ["vault", "boardroom", "elevator"],
    "rotation": ["street", "phone", "desk"],
    "alert_up": ["celebrate", "floor"],
    "alert_down": ["gloom", "floor"],
}


def _clips_for(d: Path, tag: str) -> list[Path]:
    return sorted(d.glob(f"{tag}.mp4")) + sorted(d.glob(f"{tag}_[0-9]*.mp4"))


def _rng(payload: dict) -> random.Random:
    return random.Random(f"{payload.get('show')}-{payload.get('date') or payload.get('week_start') or payload.get('detected_at')}")


def _dir(cfg) -> Path:
    d = ROOT / cfg["broll"]["dir"]
    d.mkdir(parents=True, exist_ok=True)
    return d


def pick(cfg: dict, payload: dict) -> Path | None:
    if not cfg.get("broll", {}).get("enabled"):
        return None
    show = payload["show"]
    if show == "alert":
        chg = (payload.get("quote") or {}).get("change_pct") or 0
        show = "alert_up" if chg >= 0 else "alert_down"
    d = _dir(cfg)
    rng = _rng(payload)
    for t in SHOW_TAGS.get(show, []):  # hook/outro: the first tag for this show that has footage, random variant
        clips = _clips_for(d, t)
        if clips:
            return rng.choice(clips)
    every = sorted(d.glob("*.mp4"))
    return rng.choice(every) if every else None


def cutaway_clips(cfg: dict, payload: dict, n: int) -> list[Path]:
    """Different short clips for the data cards: this show's tags first, then anything else."""
    if not cfg.get("broll", {}).get("cutaways"):
        return []
    d = _dir(cfg)
    rng = _rng(payload)
    show = payload["show"] if payload["show"] != "alert" else "alert_down"
    pool = [c for t in SHOW_TAGS.get(show, []) for c in _clips_for(d, t)]
    rest = [c for c in sorted(d.glob("*.mp4")) if c not in pool]
    rng.shuffle(pool)
    rng.shuffle(rest)
    picks = (pool + rest)[:n]
    return picks


def _video(prompt: str, cfg: dict) -> bytes:
    """Text-to-video through the official xai-sdk (handles the async job and polling)."""
    from xai_sdk import Client  # pip install xai-sdk

    client = Client(api_key=secret("XAI_API_KEY", True))
    b = cfg["broll"]
    kwargs = {"prompt": prompt, "model": b["video_model"]}
    for extra in ({"duration": b["seconds"], "aspect_ratio": "9:16", "resolution": "480p"}, {}):
        try:
            resp = client.video.generate(**kwargs, **extra)
            break
        except TypeError:
            continue  # older SDK without these options
    return requests.get(resp.url, timeout=300).content


def _image(prompt: str, cfg: dict) -> bytes:
    r = requests.post("https://api.x.ai/v1/images/generations", timeout=180,
                      headers={"Authorization": f"Bearer {secret('XAI_API_KEY', True)}"},
                      json={"model": cfg["broll"]["image_model"], "prompt": prompt, "n": 1, "response_format": "url"})
    r.raise_for_status()
    return requests.get(r.json()["data"][0]["url"], timeout=120).content


def _ken_burns(img: Path, out: Path, seconds: int):
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-loop", "1", "-i", str(img), "-t", str(seconds),
                    "-vf", f"scale=1440:2560:force_original_aspect_ratio=increase,crop=1440:2560,"
                           f"zoompan=z='min(zoom+0.0009,1.12)':d={seconds * 30}:s=1080x1920:fps=30,format=yuv420p",
                    "-c:v", "libx264", "-preset", "veryfast", "-an", str(out)], check=True)


def generate_library(cfg: dict, only: str | None = None):
    d = _dir(cfg)
    b = cfg["broll"]
    for tag, prompts in b["prompts"].items():
        if only and tag != only:
            continue
        prompts = [prompts] if isinstance(prompts, str) else prompts
        for i, prompt in enumerate(prompts):
            name = tag if i == 0 else f"{tag}_{i + 1}"
            out = d / f"{name}.mp4"
            if out.exists():
                print(f"[broll] {name}: already have it")
                continue
            print(f"[broll] {name}: generating...")
            try:
                raw = d / f"{name}_raw.mp4"
                raw.write_bytes(_video(prompt + ", vertical 9:16", cfg))
                subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(raw), "-an",
                                "-vf", "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,fps=30,format=yuv420p",
                                "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", str(out)], check=True)
                raw.unlink(missing_ok=True)
                print(f"[broll] {name}: video saved")
            except Exception as exc:
                print(f"[broll] {name}: video failed ({exc}); trying a still image instead")
                try:
                    img = d / f"{name}.png"
                    img.write_bytes(_image(prompt + ", vertical portrait composition", cfg))
                    _ken_burns(img, out, b["seconds"])
                    print(f"[broll] {name}: animated still saved")
                except Exception as exc2:
                    print(f"[broll] {name}: failed ({exc2})")
            time.sleep(1)
    print("[broll] library:", ", ".join(p.stem for p in sorted(d.glob("*.mp4")) if not p.stem.endswith("_raw")))


def bg_filter(input_idx: int, cfg: dict, theme: dict) -> str:
    """Dim, desaturate and tint the footage so it sits under the green-screen look."""
    dk = cfg["broll"].get("darken", 0.22)
    tint = "colorchannelmixer=rr=0.55:gg=0.95:bb=0.55," if theme.get("effects", {}).get("scanlines") else ""
    return (f"[{input_idx}:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1,fps=30,"
            f"eq=brightness=-{dk}:saturation=0.5,{tint}format=yuv420p[bg]")
