"""Load config.yaml and secrets from .env."""
from __future__ import annotations

import os
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent

try:
    from dotenv import load_dotenv

    load_dotenv(ROOT / ".env")
except ImportError:  # dotenv is optional
    pass


def load_config(path: str | Path | None = None) -> dict:
    path = Path(path) if path else ROOT / "config.yaml"
    with open(path) as f:
        cfg = yaml.safe_load(f)
    cfg["_root"] = str(ROOT)
    return cfg


def secret(name: str, required: bool = False) -> str | None:
    value = os.environ.get(name) or None
    if required and not value:
        raise RuntimeError(f"Missing secret {name}. Add it to .env (see .env.example).")
    return value


def load_universe(cfg: dict, key: str = "earnings") -> list[str]:
    fname = cfg[key].get("universe_file") or cfg[key].get("symbols_file")
    lines = (ROOT / fname).read_text().splitlines()
    return [l.strip().upper() for l in lines if l.strip() and not l.startswith("#")]
