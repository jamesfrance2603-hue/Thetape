"""Publishing and approval: YouTube Shorts, TikTok, Telegram review, optional HeyGen avatar."""
from __future__ import annotations

import math
import time
from pathlib import Path

import requests

from .config import secret


# ---------------------------------------------------------------- YouTube

def youtube_upload(video: Path, script: dict, cfg: dict) -> str:
    """Uploads as a Short (vertical, under 3 minutes) and declares synthetic media."""
    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build
    from googleapiclient.http import MediaFileUpload

    creds = Credentials(None, refresh_token=secret("YOUTUBE_REFRESH_TOKEN", True),
                        client_id=secret("YOUTUBE_CLIENT_ID", True), client_secret=secret("YOUTUBE_CLIENT_SECRET", True),
                        token_uri="https://oauth2.googleapis.com/token",
                        scopes=["https://www.googleapis.com/auth/youtube.upload"])
    yt = build("youtube", "v3", credentials=creds)
    tags = script.get("hashtags", [])
    body = {
        "snippet": {"title": script["title"][:95] + " #shorts",
                    "description": script["caption"] + "\n\n" + cfg["brand"]["disclaimer"] + "\n" + " ".join(f"#{t}" for t in tags),
                    "tags": tags, "categoryId": "25"},  # News & Politics; use 27 Education if you prefer
        "status": {"privacyStatus": cfg["publish"]["youtube_privacy"], "selfDeclaredMadeForKids": False,
                   "containsSyntheticMedia": True},  # AI voice or avatar -> disclose
    }
    req = yt.videos().insert(part="snippet,status", body=body, media_body=MediaFileUpload(str(video), resumable=True))
    resp = None
    while resp is None:
        _, resp = req.next_chunk()
    return f"https://youtube.com/shorts/{resp['id']}"


# ---------------------------------------------------------------- TikTok

def tiktok_upload(video: Path, script: dict, cfg: dict) -> str:
    """TikTok Content Posting API, direct post. Unaudited apps can only post with SELF_ONLY privacy."""
    token = secret("TIKTOK_ACCESS_TOKEN", True)
    size = video.stat().st_size
    chunk = min(size, 10_000_000)
    count = max(1, math.floor(size / chunk))
    title = (script["caption"] + " " + " ".join(f"#{t}" for t in script.get("hashtags", [])))[:2200]
    init = requests.post("https://open.tiktokapis.com/v2/post/publish/video/init/", timeout=60,
                         headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json; charset=UTF-8"},
                         json={"post_info": {"title": title, "privacy_level": cfg["publish"]["tiktok_privacy"],
                                             "disable_comment": False, "is_aigc": True},  # AI-generated label
                               "source_info": {"source": "FILE_UPLOAD", "video_size": size,
                                               "chunk_size": chunk, "total_chunk_count": count}})
    init.raise_for_status()
    data = init.json()["data"]
    with open(video, "rb") as f:
        for i in range(count):
            start = i * chunk
            end = size - 1 if i == count - 1 else start + chunk - 1
            f.seek(start)
            part = f.read(end - start + 1)
            requests.put(data["upload_url"], data=part, timeout=300, headers={
                "Content-Type": "video/mp4", "Content-Range": f"bytes {start}-{end}/{size}"}).raise_for_status()
    return f"tiktok publish_id {data['publish_id']}"


# ---------------------------------------------------------------- Telegram review

def _tg(method: str, **kw):
    token = secret("TELEGRAM_BOT_TOKEN")
    if not token:
        return None
    r = requests.post(f"https://api.telegram.org/bot{token}/{method}", timeout=300, **kw)
    r.raise_for_status()
    return r.json()


def send_for_review(run_id: str, video: Path, script: dict, report: dict):
    flags = []
    if report["advice_flags"]:
        flags.append("ADVICE WORDING: " + ", ".join(report["advice_flags"]))
    if report["unverified_numbers"]:
        flags.append("NUMBERS NOT IN DATA: " + ", ".join(report["unverified_numbers"]))
    if script.get("writer_error"):
        flags.append("Model failed, template script used")
    urgent = "BREAKING DRAFT, approve fast\n" if script.get("show") == "alert" else ""
    caption = (urgent + f"{script['title']}\n\n" + ("\n".join(flags) if flags else "Compliance: clean") +
               f"\n\nReply /approve {run_id} to post, or /reject {run_id}")
    with open(video, "rb") as f:
        _tg("sendVideo", data={"chat_id": secret("TELEGRAM_CHAT_ID"), "caption": caption[:1024]}, files={"video": f})


def poll_commands(offset: int | None = None) -> tuple[list[tuple[str, str]], int | None]:
    res = _tg("getUpdates", data={"timeout": 50, **({"offset": offset} if offset else {})})
    cmds, last = [], offset
    for u in (res or {}).get("result", []):
        last = u["update_id"] + 1
        msg = u.get("message") or {}
        if str(msg.get("chat", {}).get("id")) != str(secret("TELEGRAM_CHAT_ID")):
            continue  # only you can approve
        parts = (msg.get("text") or "").split()
        if len(parts) == 2 and parts[0] in ("/approve", "/reject", "/posted"):
            cmds.append((parts[0][1:], parts[1]))
    return cmds, last


def _post_texts(script: dict, cfg: dict) -> dict:
    tags = [t.lstrip("#").replace(" ", "") for t in script.get("hashtags", [])][:5]
    disc = cfg["brand"]["disclaimer"]
    title = script["title"][:95]
    yt_desc = f"{script['caption']}\n\n{disc}\n\n" + " ".join(f"#{t}" for t in tags + ["shorts"])
    tt = (f"{script['caption']} {' '.join('#' + t for t in tags)}")[:2200]
    return {"yt_title": title, "yt_desc": yt_desc, "tiktok": tt}


def send_post_kit(run_id: str, video: Path, script: dict, cfg: dict):
    """Manual-posting mode: full-quality file plus each piece of text in its own message (tap and hold to copy)."""
    chat = secret("TELEGRAM_CHAT_ID")
    t = _post_texts(script, cfg)
    _tg("sendMessage", data={"chat_id": chat, "text": f"Approved {run_id}. Post kit below: save the video, then copy each text."})
    with open(video, "rb") as f:
        _tg("sendDocument", data={"chat_id": chat, "caption": "Full-quality video: tap, then share, then Save Video"},
            files={"document": (f"thetape_{run_id}.mp4", f, "video/mp4")})
    _tg("sendMessage", data={"chat_id": chat, "text": "YOUTUBE TITLE \u2193"})
    _tg("sendMessage", data={"chat_id": chat, "text": t["yt_title"]})
    _tg("sendMessage", data={"chat_id": chat, "text": "YOUTUBE DESCRIPTION \u2193"})
    _tg("sendMessage", data={"chat_id": chat, "text": t["yt_desc"]})
    _tg("sendMessage", data={"chat_id": chat, "text": "TIKTOK CAPTION \u2193"})
    _tg("sendMessage", data={"chat_id": chat, "text": t["tiktok"]})
    _tg("sendMessage", data={"chat_id": chat, "text":
        "Checklist: YouTube: tick 'Altered or synthetic content: Yes'. "
        "TikTok: More options, then turn on 'AI-generated content'. Reply /posted " + run_id + " when done."})
    return t


def notify(text: str):
    _tg("sendMessage", data={"chat_id": secret("TELEGRAM_CHAT_ID"), "text": text})


# ---------------------------------------------------------------- HeyGen avatar (optional)

def heygen_video(script_text: str, cfg: dict, out: Path) -> Path:
    """Talking-avatar version. Not monetisable for finance on YouTube or TikTok (see playbook)."""
    key = secret("HEYGEN_API_KEY", True)
    h = {"X-Api-Key": key, "Content-Type": "application/json"}
    r = requests.post("https://api.heygen.com/v2/video/generate", headers=h, timeout=60, json={
        "video_inputs": [{"character": {"type": "avatar", "avatar_id": cfg["avatar"]["heygen_avatar_id"]},
                          "voice": {"type": "text", "input_text": script_text, "voice_id": cfg["avatar"]["heygen_voice_id"]}}],
        "dimension": {"width": 1080, "height": 1920}})
    r.raise_for_status()
    vid = r.json()["data"]["video_id"]
    for _ in range(120):
        s = requests.get("https://api.heygen.com/v1/video_status.get", params={"video_id": vid}, headers=h, timeout=30).json()["data"]
        if s["status"] == "completed":
            path = out / "avatar.mp4"
            path.write_bytes(requests.get(s["video_url"], timeout=300).content)
            return path
        if s["status"] == "failed":
            raise RuntimeError(s.get("error"))
        time.sleep(10)
    raise TimeoutError("HeyGen render timed out")
