"""MarketPage: automated, data-led finance shorts for TikTok and YouTube."""
