"""Demo payloads so the whole pipeline runs with no API keys.

All figures are invented placeholders for testing the render. Never publish demo output.
"""
from __future__ import annotations

from datetime import date, timedelta

from .analytics import next_week_range


def daily(today: date) -> dict:
    return {
        "show": "daily", "date": today.isoformat(), "demo": True,
        "indices": {"SPY": {"last": 581.2, "change_pct": 0.42}, "QQQ": {"last": 502.7, "change_pct": 0.81},
                    "DIA": {"last": 428.9, "change_pct": -0.12}, "IWM": {"last": 221.4, "change_pct": 0.35},
                    "VIX": {"last": 16.8, "change_pct": -4.1}},
        "economic_calendar": [
            {"time": f"{today}T12:30:00", "country": "US", "event": "Core PCE Price Index MoM", "estimate": 0.3, "previous": 0.2},
            {"time": f"{today}T14:00:00", "country": "US", "event": "Michigan Consumer Sentiment", "estimate": 70.5, "previous": 69.8}],
        "earnings_today": [
            {"symbol": "XOM", "date": today.isoformat(), "session": "bmo", "spot": 118.4,
             "implied": {"implied_move_pct": 2.6}, "history": {"avg_move_pct": 1.9}, "ratio": 1.37, "verdict": "rich", "move_usd": 3.08},
            {"symbol": "ABBV", "date": today.isoformat(), "session": "bmo", "spot": 192.1,
             "implied": {"implied_move_pct": 3.4}, "history": {"avg_move_pct": 3.8}, "ratio": 0.89, "verdict": "in line", "move_usd": 6.53}],
        "news": [
            {"title": "Big Tech earnings lift Nasdaq futures after cloud revenue beats", "source": "sample"},
            {"title": "Treasury yields slip ahead of inflation data", "source": "sample"},
            {"title": "Oil steadies as OPEC+ signals output pause", "source": "sample"},
            {"title": "Chipmaker shares rise on AI server demand outlook", "source": "sample"}],
    }


def weekly(today: date) -> dict:
    s, e = next_week_range(today)
    d = lambda i: (s + timedelta(days=i)).isoformat()
    rows = [("NVDA", d(2), "amc", 182.5, 7.9, 6.1), ("PLTR", d(0), "amc", 171.3, 11.8, 14.6),
            ("AMD", d(1), "amc", 247.0, 7.4, 6.8), ("SHOP", d(1), "bmo", 158.2, 9.6, 12.9),
            ("UBER", d(1), "bmo", 97.4, 6.8, 6.4), ("DIS", d(3), "bmo", 113.9, 4.9, 4.2),
            ("ABNB", d(3), "amc", 131.6, 8.1, 9.7), ("COIN", d(3), "amc", 342.8, 9.9, 7.5)]
    board = []
    for sym, dt, sess, spot, imp, hist in rows:
        ratio = round(imp / hist, 2)
        board.append({"symbol": sym, "date": dt, "session": sess, "spot": spot,
                      "implied": {"implied_move_pct": imp}, "history": {"avg_move_pct": hist},
                      "ratio": ratio, "verdict": "rich" if ratio >= 1.2 else "cheap" if ratio <= 0.8 else "in line",
                      "move_usd": round(spot * imp / 100, 2)})
    return {"show": "weekly", "demo": True, "week_start": s.isoformat(), "week_end": e.isoformat(), "earnings": board,
            "economic_calendar": [{"time": f"{d(2)}T12:30:00", "country": "US", "event": "CPI YoY", "estimate": 2.9, "previous": 3.0},
                                  {"time": f"{d(3)}T12:00:00", "country": "GB", "event": "BoE Interest Rate Decision", "estimate": 3.75, "previous": 4.0}]}


def radar(today: date) -> dict:
    exp = (today + timedelta(days=14)).isoformat()
    return {"show": "radar", "demo": True, "date": today.isoformat(), "unusual": [
        {"symbol": "TSLA", "option_type": "call", "strike": 500, "expiry": exp, "dte": 14, "volume": 48210,
         "open_interest": 6120, "vol_oi": 7.9, "premium_usd": 21700000, "mid": 4.5, "otm_pct": 8.6, "spot": 460.4, "breakeven": 504.5},
        {"symbol": "AMD", "option_type": "put", "strike": 230, "expiry": exp, "dte": 14, "volume": 15400,
         "open_interest": 2210, "vol_oi": 7.0, "premium_usd": 5390000, "mid": 3.5, "otm_pct": -6.9, "spot": 247.0, "breakeven": 226.5},
        {"symbol": "SOFI", "option_type": "call", "strike": 32, "expiry": exp, "dte": 14, "volume": 39800,
         "open_interest": 9050, "vol_oi": 4.4, "premium_usd": 2390000, "mid": 0.6, "otm_pct": 9.4, "spot": 29.25, "breakeven": 32.6}]}


def recap(today: date) -> dict:
    monday = today - timedelta(days=today.weekday())
    return {"show": "recap", "demo": True, "week_of": monday.isoformat(),
            "index_week_pct": {"SPY": 1.12, "QQQ": 1.86, "DIA": 0.41, "IWM": -0.35},
            "earnings_results": [
                {"symbol": "META", "actual_move_pct": 11.3, "implied_move_pct": 7.2},
                {"symbol": "MSFT", "actual_move_pct": 2.1, "implied_move_pct": 4.6},
                {"symbol": "AMZN", "actual_move_pct": 8.4, "implied_move_pct": 6.9}]}


def alert(today: date) -> dict:
    return {"show": "alert", "demo": True, "kind": "mover", "symbol": "SMCI", "company": "Super Micro Computer Inc",
            "detected_at": f"{today}T15:42:00+00:00",
            "quote": {"last": 38.12, "change_pct": -14.6, "volume": 61200000, "average_volume": 24800000,
                      "high": 44.9, "low": 37.6, "prevclose": 44.64},
            "headlines": [{"title": "Super Micro shares slide after auditor raises questions over filing timeline", "source": "sample wire"},
                          {"title": "Analyst cuts rating on server maker citing margin pressure", "source": "sample wire"}],
            "x_chatter": {"summary": "Posts on X focus on the filing delay; several accounts speculate about guidance, unconfirmed.",
                          "citations": []}}


def reaction(today: date) -> dict:
    rows = [("PLTR", 14.9, -6.2, 11.8, 12.4, 3.1), ("AMD", 7.4, -9.6, 7.4, -4.0, -1.2),
            ("SHOP", 9.6, 4.1, 9.6, 8.7, 2.3), ("UBER", 6.8, 1.9, 6.8, 2.2, 0.4)]
    res = []
    for sym, _, mv, imp, eps_s, rev_s in rows:
        res.append({"symbol": sym, "move_pct": mv, "actual_move_pct": abs(mv), "implied_move_pct": imp,
                    "eps_surprise_pct": eps_s, "rev_surprise_pct": rev_s, "move_vs_implied": round(abs(mv) / imp, 2)})
    res.sort(key=lambda r: -r["move_vs_implied"])
    return {"show": "reaction", "demo": True, "date": today.isoformat(), "results": res}


def sector(today: date) -> dict:
    st = [("NVDA", 46.1, 31.2, 38.5), ("AVGO", 58.3, 33.8, 27.9), ("AMD", 98.4, 29.6, 41.0), ("TSM", 24.2, 19.8, 18.6),
          ("QCOM", 16.9, 13.7, 17.2), ("TXN", 34.0, 30.1, 24.4), ("INTC", None, 27.5, 13.9), ("MU", 22.8, 9.4, 11.6)]
    stocks = [{"symbol": s, "pe_ttm": a, "fwd_pe": f, "hist_pe_median": h, "vs_history_pct": round((f / h - 1) * 100)}
              for s, a, f, h in st]
    return {"show": "sector", "demo": True, "date": today.isoformat(), "sector": "Semiconductors", "history_years": 5,
            "stocks": stocks, "summary": {"median_pe_ttm": 34.0, "median_fwd_pe": 28.6, "median_hist_pe": 21.4, "vs_history_pct": 34}}


def dividends(today: date) -> dict:
    mk = lambda s, y, p, f, d, g, sc: {"symbol": s, "yield_pct": y, "payout_pct": p, "fcf_payout_pct": f,
                                       "net_debt_ebitda": d, "div_cagr_5y_pct": g, "cover_score": sc}
    return {"show": "dividends", "demo": True, "date": today.isoformat(), "universe_size": 32,
            "top": [mk("ITW", 2.3, 52.1, 49.0, 1.4, 7.1, 86), mk("PH", 1.0, 25.4, 18.9, 1.9, 14.2, 84),
                    mk("LOW", 1.9, 36.0, 34.8, 2.6, 15.8, 81), mk("CSL", 1.1, 18.2, 15.0, 1.6, 21.0, 80),
                    mk("PG", 2.5, 61.0, 58.7, 1.3, 5.6, 72)],
            "weakest": [mk("MO", 7.1, 78.5, 79.2, 2.2, 4.0, 41), mk("SWK", 4.2, 105.0, 96.0, 4.1, 2.5, 18)]}


def rotation(today: date) -> dict:
    data = [("SMH", "Semiconductors", 3.1, 9.4, 18.2), ("XLU", "Utilities", 1.2, 5.6, 4.1), ("GDX", "Gold miners", -2.0, 4.9, 15.8),
            ("ITA", "Defence", 0.4, 3.0, 6.2), ("XLK", "Tech", 1.0, 2.1, 7.5), ("XLF", "Financials", -0.4, -0.8, -1.1),
            ("XLE", "Energy", -1.6, -3.4, -6.0), ("XBI", "Biotech", -2.2, -4.1, 2.5), ("KRE", "Regional banks", -1.9, -5.3, -8.8),
            ("XLRE", "Real estate", -0.8, -6.0, -4.4)]
    rows = [{"symbol": s, "label": l, "rel_w1": a, "rel_m1": b, "rel_m3": c, "shift": round(b - c / 3, 1)} for s, l, a, b, c in data]
    rows.sort(key=lambda r: -r["rel_m1"])
    return {"show": "rotation", "demo": True, "date": today.isoformat(), "benchmark": "SPY",
            "benchmark_returns": {"w1": 0.9, "m1": 2.4, "m3": 5.8}, "etfs": rows, "leaders": rows[:3], "laggards": rows[-3:][::-1],
            "turning_up": sorted(rows, key=lambda r: -r["shift"])[:2], "turning_down": sorted(rows, key=lambda r: r["shift"])[:2]}


SAMPLES = {"daily": daily, "weekly": weekly, "radar": radar, "recap": recap, "alert": alert,
           "reaction": reaction, "sector": sector, "dividends": dividends, "rotation": rotation}
