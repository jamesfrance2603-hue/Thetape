"""Demo payloads so the whole pipeline runs with no API keys.

All figures are invented placeholders for testing the render. Never publish demo output.
"""
from __future__ import annotations

from datetime import date, timedelta

from .analytics import next_week_range


def daily(today: date) -> dict:
    return {
        "show": "daily", "date": today.isoformat(), "demo": True,
        "indices": {"SPY": {"last": 581.2, "change_pct": 0.42}, "QQQ": {"last": 502.7, "change_pct": 0.81},
                    "DIA": {"last": 428.9, "change_pct": -0.12}, "IWM": {"last": 221.4, "change_pct": 0.35},
                    "VIX": {"last": 16.8, "change_pct": -4.1}},
        "economic_calendar": [
            {"time": f"{today}T12:30:00", "country": "US", "event": "Core PCE Price Index MoM", "estimate": 0.3, "previous": 0.2},
            {"time": f"{today}T14:00:00", "country": "US", "event": "Michigan Consumer Sentiment", "estimate": 70.5, "previous": 69.8}],
        "earnings_today": [
            {"symbol": "XOM", "date": today.isoformat(), "session": "bmo", "spot": 118.4,
             "implied": {"implied_move_pct": 2.6}, "history": {"avg_move_pct": 1.9}, "ratio": 1.37, "verdict": "rich", "move_usd": 3.08},
            {"symbol": "ABBV", "date": today.isoformat(), "session": "bmo", "spot": 192.1,
             "implied": {"implied_move_pct": 3.4}, "history": {"avg_move_pct": 3.8}, "ratio": 0.89, "verdict": "in line", "move_usd": 6.53}],
        "news": [
            {"title": "Big Tech earnings lift Nasdaq futures after cloud revenue beats", "source": "sample"},
            {"title": "Treasury yields slip ahead of inflation data", "source": "sample"},
            {"title": "Oil steadies as OPEC+ signals output pause", "source": "sample"},
            {"title": "Chipmaker shares rise on AI server demand outlook", "source": "sample"}],
    }


def weekly(today: date) -> dict:
    s, e = next_week_range(today)
    d = lambda i: (s + timedelta(days=i)).isoformat()
    rows = [("NVDA", d(2), "amc", 182.5, 7.9, 6.1), ("PLTR", d(0), "amc", 171.3, 11.8, 14.6),
            ("AMD", d(1), "amc", 247.0, 7.4, 6.8), ("SHOP", d(1), "bmo", 158.2, 9.6, 12.9),
            ("UBER", d(1), "bmo", 97.4, 6.8, 6.4), ("DIS", d(3), "bmo", 113.9, 4.9, 4.2),
            ("ABNB", d(3), "amc", 131.6, 8.1, 9.7), ("COIN", d(3), "amc", 342.8, 9.9, 7.5)]
    board = []
    for sym, dt, sess, spot, imp, hist in rows:
        ratio = round(imp / hist, 2)
        board.append({"symbol": sym, "date": dt, "session": sess, "spot": spot,
                      "implied": {"implied_move_pct": imp}, "history": {"avg_move_pct": hist},
                      "ratio": ratio, "verdict": "rich" if ratio >= 1.2 else "cheap" if ratio <= 0.8 else "in line",
                      "move_usd": round(spot * imp / 100, 2)})
    return {"show": "weekly", "demo": True, "week_start": s.isoformat(), "week_end": e.isoformat(), "earnings": board,
            "economic_calendar": [{"time": f"{d(2)}T12:30:00", "country": "US", "event": "CPI YoY", "estimate": 2.9, "previous": 3.0},
                                  {"time": f"{d(3)}T12:00:00", "country": "GB", "event": "BoE Interest Rate Decision", "estimate": 3.75, "previous": 4.0}]}


def radar(today: date) -> dict:
    exp = (today + timedelta(days=14)).isoformat()
    return {"show": "radar", "demo": True, "date": today.isoformat(), "unusual": [
        {"symbol": "TSLA", "option_type": "call", "strike": 500, "expiry": exp, "dte": 14, "volume": 48210,
         "open_interest": 6120, "vol_oi": 7.9, "premium_usd": 21700000, "mid": 4.5, "otm_pct": 8.6, "spot": 460.4, "breakeven": 504.5},
        {"symbol": "AMD", "option_type": "put", "strike": 230, "expiry": exp, "dte": 14, "volume": 15400,
         "open_interest": 2210, "vol_oi": 7.0, "premium_usd": 5390000, "mid": 3.5, "otm_pct": -6.9, "spot": 247.0, "breakeven": 226.5},
        {"symbol": "SOFI", "option_type": "call", "strike": 32, "expiry": exp, "dte": 14, "volume": 39800,
         "open_interest": 9050, "vol_oi": 4.4, "premium_usd": 2390000, "mid": 0.6, "otm_pct": 9.4, "spot": 29.25, "breakeven": 32.6}]}


def recap(today: date) -> dict:
    monday = today - timedelta(days=today.weekday())
    return {"show": "recap", "demo": True, "week_of": monday.isoformat(),
            "index_week_pct": {"SPY": 1.12, "QQQ": 1.86, "DIA": 0.41, "IWM": -0.35},
            "earnings_results": [
                {"symbol": "META", "actual_move_pct": 11.3, "implied_move_pct": 7.2},
                {"symbol": "MSFT", "actual_move_pct": 2.1, "implied_move_pct": 4.6},
                {"symbol": "AMZN", "actual_move_pct": 8.4, "implied_move_pct": 6.9}]}


def alert(today: date) -> dict:
    return {"show": "alert", "demo": True, "kind": "mover", "symbol": "SMCI", "company": "Super Micro Computer Inc",
            "detected_at": f"{today}T15:42:00+00:00",
            "quote": {"last": 38.12, "change_pct": -14.6, "volume": 61200000, "average_volume": 24800000,
                      "high": 44.9, "low": 37.6, "prevclose": 44.64},
            "headlines": [{"title": "Super Micro shares slide after auditor raises questions over filing timeline", "source": "sample wire"},
                          {"title": "Analyst cuts rating on server maker citing margin pressure", "source": "sample wire"}],
            "x_chatter": {"summary": "Posts on X focus on the filing delay; several accounts speculate about guidance, unconfirmed.",
                          "citations": []}}


SAMPLES = {"daily": daily, "weekly": weekly, "radar": radar, "recap": recap, "alert": alert}
