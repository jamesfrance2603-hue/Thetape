"""Breaking-news and big-mover watcher.

Runs every few minutes through the UK trading day. It raises an alert when:
  1. a covered stock moves more than its threshold (bigger caps need a smaller move to count), or
  2. a market-wide headline breaks that matches the high-impact keyword list.
Each alert gathers the move, the news wire headlines and (if enabled) what X is saying via Grok,
then the normal pipeline writes, checks, renders and sends it to Telegram for one-tap approval.
"""
from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path

from .config import ROOT, load_universe
from .providers import Finnhub, Tradier, grok_x_search, rss_news

STATE = ROOT / "state"


def _state_path(day: str) -> Path:
    STATE.mkdir(exist_ok=True)
    return STATE / f"alerts_{day}.json"


def load_state(day: str) -> dict:
    p = _state_path(day)
    return json.loads(p.read_text()) if p.exists() else {"symbols": {}, "headlines": [], "sent": []}


def save_state(day: str, st: dict):
    _state_path(day).write_text(json.dumps(st, indent=2))


def threshold_for(symbol: str, a: dict) -> float:
    return a["mega_cap_move_pct"] if symbol in a["mega_caps"] else a["move_pct"]


def find_movers(quotes: dict, a: dict, st: dict) -> list[dict]:
    """Stocks past their threshold that haven't alerted today, or have moved a further step since."""
    hits = []
    for sym, q in quotes.items():
        chg, last = q.get("change_pct"), q.get("last")
        if chg is None or not last or last < a["min_price"]:
            continue
        if abs(chg) < threshold_for(sym, a):
            continue
        prev = st["symbols"].get(sym)
        if prev is not None and abs(chg) < abs(prev) + a["re_alert_step_pct"]:
            continue
        hits.append({"symbol": sym, "quote": q, "score": abs(chg) / threshold_for(sym, a)})
    return sorted(hits, key=lambda h: -h["score"])


def find_breaking(news: list[dict], a: dict, st: dict) -> list[dict]:
    kw = re.compile(r"\b(" + "|".join(a["breaking_keywords"]) + r")\b", re.I)
    out = []
    for n in news:
        key = n["title"].lower()[:80]
        if key in st["headlines"] or not kw.search(n["title"]):
            continue
        out.append(n)
    return out


def can_send(st: dict, a: dict, now: datetime) -> bool:
    if len(st["sent"]) >= a["max_alerts_per_day"]:
        return False
    if st["sent"]:
        last = datetime.fromisoformat(st["sent"][-1])
        if (now - last).total_seconds() < a["cooldown_minutes"] * 60:
            return False
    return True


def mover_payload(cfg: dict, hit: dict, now: datetime) -> dict:
    sym, q = hit["symbol"], hit["quote"]
    fh = Finnhub(cfg["providers"]["finnhub_base"])
    headlines = fh.company_news(sym, now.date())[:4]
    direction = "down" if (q.get("change_pct") or 0) < 0 else "up"
    x = {}
    if cfg["alerts"].get("use_x_search"):
        x = grok_x_search(f"Why is ${sym} stock {direction} {abs(q['change_pct']):.1f}% today?", cfg["writer"]["xai_model"])
    return {"show": "alert", "kind": "mover", "symbol": sym, "company": q.get("description"), "quote": q,
            "detected_at": now.isoformat(), "headlines": headlines, "x_chatter": x}


def news_payload(cfg: dict, item: dict, quotes: dict, now: datetime) -> dict:
    x = {}
    if cfg["alerts"].get("use_x_search"):
        x = grok_x_search(f"Market reaction to: {item['title']}", cfg["writer"]["xai_model"], hours=2)
    idx = {k: quotes[k] for k in cfg["market"]["index_symbols"] if k in quotes}
    return {"show": "alert", "kind": "news", "symbol": None, "detected_at": now.isoformat(),
            "headlines": [item], "indices": idx, "x_chatter": x}


def scan(cfg: dict, now: datetime | None = None) -> list[dict]:
    """One pass of the watcher. Returns alert payloads ready for run.build()."""
    now = now or datetime.now(timezone.utc)
    a = cfg["alerts"]
    day = now.date().isoformat()
    st = load_state(day)
    if not can_send(st, a, now):
        return []
    tr = Tradier(cfg["providers"]["tradier_base"])
    syms = load_universe(cfg) + cfg["market"]["index_symbols"]
    quotes = tr.quotes(syms)
    payloads = []
    for hit in find_movers({k: v for k, v in quotes.items() if k not in cfg["market"]["index_symbols"]}, a, st)[:1]:
        payloads.append(mover_payload(cfg, hit, now))
        st["symbols"][hit["symbol"]] = hit["quote"]["change_pct"]
    if not payloads and a.get("breaking_news"):
        news = rss_news(cfg["news"]["rss"], 1, 60)
        for item in find_breaking(news, a, st)[:1]:
            payloads.append(news_payload(cfg, item, quotes, now))
            st["headlines"].append(item["title"].lower()[:80])
    if payloads:
        st["sent"].append(now.isoformat())
    save_state(day, st)
    return payloads


def in_window(now_local: datetime, a: dict) -> bool:
    if now_local.weekday() >= 5:
        return False
    hm = now_local.strftime("%H:%M")
    return a["window_start"] <= hm <= a["window_end"]
