"""Guardrails run on every script before it can be rendered or published.

1. Advice language: the page reports data, it never tells anyone to trade.
2. Number check: every figure in the voiceover and cards must exist in the data payload.
   This stops the model inventing numbers, which is the biggest risk in an automated finance page.
"""
from __future__ import annotations

import re

ADVICE_PATTERNS = [
    r"\byou should (buy|sell|short|hold)\b", r"\b(buy|sell|short) (now|this|it|the dip)\b",
    r"\bstrong buy\b", r"\bguarantee[sd]?\b", r"\brisk[- ]free\b", r"\bcan'?t lose\b",
    r"\bfree money\b", r"\bto the moon\b", r"\bprice target\b", r"\bwe recommend\b",
    r"\bget in (now|before)\b", r"\bnot to be missed\b", r"\bsure thing\b",
]

NUM_RE = re.compile(r"(?<![A-Za-z])[-+]?\$?\d[\d,]*\.?\d*%?")


UNVERIFIED_KEYS = {"x_chatter", "citations", "url"}  # numbers here are never accepted as facts


def _flatten_numbers(obj, out: set[float]) -> set[float]:
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k not in UNVERIFIED_KEYS:
                _flatten_numbers(v, out)
    elif isinstance(obj, list):
        for v in obj:
            _flatten_numbers(v, out)
    elif isinstance(obj, bool):
        pass
    elif isinstance(obj, (int, float)):
        out.add(float(obj))
    elif isinstance(obj, str):
        for m in NUM_RE.findall(obj):
            try:
                out.add(float(m.strip("$%+").replace(",", "")))
            except ValueError:
                pass
    return out


def _matches(x: float, known: set[float]) -> bool:
    for k in known:
        for cand in (k, abs(k)):
            if abs(x - cand) <= max(0.051, abs(cand) * 0.005):
                return True
            # allow natural rounding a presenter would use: 21,700,000 -> 21.7 (million)
            for scale in (1e3, 1e6, 1e9, 1e12):
                if abs(x - cand / scale) <= 0.051 and cand / scale >= 1:
                    return True
    return False


NAMES_WITH_NUMBERS = ["S&P 500", "Nasdaq 100", "Nasdaq-100", "Russell 2000", "FTSE 100", "FTSE 250",
                      "Stoxx 600", "Nikkei 225", "in 60 seconds", "24/7", "401(k)", "Web3"]

ALLOWED_SMALL ={float(i) for i in range(0, 13)}  # counts like "3 stocks", "top 5"


def check(script: dict, payload: dict) -> dict:
    from .writer import script_text

    text = script_text(script)
    for name in NAMES_WITH_NUMBERS:  # index names and show names are not figures
        text = re.sub(re.escape(name), "", text, flags=re.I)
    lowered = text.lower()
    advice = [p for p in ADVICE_PATTERNS if re.search(p, lowered)]
    known = _flatten_numbers(payload, set()) | ALLOWED_SMALL
    # years and dates in the payload are fine
    for d in re.findall(r"\d{4}-\d{2}-\d{2}", str(payload)):
        y, mo, da = d.split("-")
        known |= {float(y), float(int(mo)), float(int(da))}
    unverified = []
    for m in NUM_RE.findall(text):
        try:
            x = float(m.strip("$%+").replace(",", ""))
        except ValueError:
            continue
        if not _matches(x, known):
            unverified.append(m)
    return {"advice_flags": advice, "unverified_numbers": sorted(set(unverified)),
            "clean": not advice and not unverified}
