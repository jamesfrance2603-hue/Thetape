"""Render a script + payload into a 1080x1920 vertical MP4.

Visuals are drawn by code from the payload (never from model text), voice from the script.
The look is set by `theme` in config.yaml: `trading_floor` (80s/90s green-screen terminal with a
scrolling ticker tape) or `modern` (clean dark cards).
"""
from __future__ import annotations

import json
import shutil
import subprocess
from datetime import date, datetime
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib import font_manager  # noqa: E402
import requests  # noqa: E402
from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont  # noqa: E402

from . import broll  # noqa: E402
from .config import ROOT, secret  # noqa: E402

W, H = 1080, 1920
SYS_FONT_DIRS = ["/usr/share/fonts/opentype/inter", "/usr/share/fonts/truetype/dejavu", "/Library/Fonts", "C:/Windows/Fonts"]
THEME: dict = {}
TICKER_Y, TICKER_H = 112, 76
CONTENT_TOP = 250


def set_theme(cfg: dict) -> dict:
    global THEME
    THEME = cfg["themes"][cfg.get("theme", "modern")]
    return THEME


def _font(size: int, weight: str = "Regular", role: str | None = None) -> ImageFont.FreeTypeFont:
    fonts = THEME.get("fonts")
    if fonts:
        role = role or ("bold" if weight in ("Bold", "Black", "SemiBold") else "body")
        size = int(size * THEME.get("font_scale", {}).get(role, 1))
        return ImageFont.truetype(str(ROOT / fonts[role]), size)
    names = [f"Inter-{weight}.otf", "DejaVuSans-Bold.ttf" if weight in ("Bold", "Black") else "DejaVuSans.ttf", "arial.ttf"]
    for d in SYS_FONT_DIRS:
        for n in names:
            if (Path(d) / n).exists():
                return ImageFont.truetype(str(Path(d) / n), size)
    return ImageFont.load_default(size)


def _wrap(s: str, font, max_px: int) -> list[str]:
    lines, cur = [], ""
    for word in s.split():
        trial = f"{cur} {word}".strip()
        if font.getlength(trial) <= max_px:
            cur = trial
        else:
            if cur:
                lines.append(cur)
            cur = word
    return lines + ([cur] if cur else [])


class Canvas:
    def __init__(self, cfg: dict):
        self.c = THEME["colors"]
        self.fx = THEME.get("effects", {})
        self.brand = cfg["brand"]
        self.retro = bool(self.fx.get("scanlines"))
        self.img = Image.new("RGB", (W, H), self.c["bg"])
        self.d = ImageDraw.Draw(self.img)

    def text(self, xy, s, size=48, weight="Regular", color=None, anchor="la", role=None):
        self.d.text(xy, s, font=_font(size, weight, role), fill=color or self.c["text"], anchor=anchor)

    def wrapped(self, x, y, s, size=48, weight="Regular", color=None, max_px=W - 144, gap=1.22, role=None,
                anchor="la", max_lines=99) -> int:
        f = _font(size, weight, role)
        for line in _wrap(s, f, max_px)[:max_lines]:
            self.d.text((x, y), line, font=f, fill=color or self.c["text"], anchor=anchor)
            y += int(f.size * gap)
        return y

    def panel(self, x0, y0, x1, y1, fill=None, outline=None):
        r = 6 if self.retro else 28
        self.d.rounded_rectangle((x0, y0, x1, y1), radius=r, fill=fill or self.c["panel"],
                                 outline=outline or (self.c["line"] if self.retro else None), width=2)

    def label(self, s: str) -> str:
        return f"[ {s.upper()} ]" if self.retro else s

    def frame(self, headline: str, subtitle: str = "", stamp: str = ""):
        c = self.c
        if self.retro:
            self.d.rectangle((60, 50, 74, 86), fill=c["accent"])
            self.text((90, 58), self.brand["name"].upper(), 40, role="display", color=c["accent"])
            self.text((W - 60, 58), stamp or datetime.utcnow().strftime("%d %b %y  %H:%M GMT").upper(), 34,
                      role="display", color=c["muted"], anchor="ra")
            self.d.rectangle((0, TICKER_Y, W, TICKER_Y + TICKER_H), fill=c["tape_bg"])
            self.d.line((0, TICKER_Y, W, TICKER_Y), fill=c["accent"], width=2)
            self.d.line((0, TICKER_Y + TICKER_H, W, TICKER_Y + TICKER_H), fill=c["accent"], width=2)
            y = CONTENT_TOP
            if headline:
                y = self.wrapped(60, y, headline.upper(), 92, role="display", max_px=W - 120, gap=0.95)
        else:
            self.text((72, 150), self.brand["name"].upper(), 34, "Bold", c["accent"])
            self.text((W - 72, 150), self.brand["handle"], 30, "Regular", c["muted"], anchor="ra")
            y = self.wrapped(72, 230, headline, 72, "Bold", gap=1.12) if headline else 230
        if subtitle:
            y = self.wrapped(60 if self.retro else 72, y + 18, subtitle, 34, color=c["muted"])
        self.wrapped(W // 2, H - 96, self.brand["disclaimer"], 22, color=c["muted"], anchor="ma", max_px=W - 120)
        return y + 36

    def caption(self, vo: str):
        """Burned-in subtitle of the voiceover: most viewers watch muted."""
        if not vo:
            return
        f = _font(42, "SemiBold")
        lines = _wrap(vo, f, W - 200)[:5]
        lh = int(f.size * 1.3)
        y0 = H - 210 - len(lines) * lh
        self.panel(48, y0 - 30, W - 48, H - 170, fill="#000000", outline=self.c["accent"] if self.retro else None)
        for i, l in enumerate(lines):
            self.d.text((W // 2, y0 + i * lh), l, font=f, fill=self.c["text"], anchor="ma")

    def finish(self) -> Image.Image:
        return crt(self.img) if self.retro else self.img

    def save(self, path: Path):
        self.finish().save(path)


def crt(img: Image.Image) -> Image.Image:
    """Phosphor glow, scanlines and vignette."""
    fx = THEME.get("effects", {})
    out = img
    if fx.get("glow"):
        bloom = img.filter(ImageFilter.GaussianBlur(7))
        out = ImageChops.screen(img, Image.eval(bloom, lambda v: int(v * 0.55)))
    if fx.get("scanlines"):
        lines = Image.new("L", out.size, 255)
        dl = ImageDraw.Draw(lines)
        for y in range(0, out.height, 4):
            dl.line((0, y, out.width, y), fill=200)
        out = ImageChops.multiply(out, Image.merge("RGB", [lines] * 3))
    if fx.get("vignette"):
        mask = Image.new("L", (out.width // 8, out.height // 8), 0)
        ImageDraw.Draw(mask).ellipse((-20, -40, mask.width + 20, mask.height + 40), fill=255)
        mask = mask.filter(ImageFilter.GaussianBlur(28)).resize(out.size)
        dark = Image.eval(out, lambda v: int(v * 0.45))
        out = Image.composite(out, dark, mask)
    return out


# ---------------------------------------------------------------- shared pieces

def _pct(x, signed=True, nd=1):
    return "n/a" if x is None else f"{x:+.{nd}f}%" if signed else f"{x:.{nd}f}%"


def _col(cv: Canvas, x):
    return cv.c["muted"] if x is None else cv.c["up"] if x >= 0 else cv.c["down"]


def _tiles(cv: Canvas, y, items: list[tuple[str, str, float | None]]):
    tw, th = (W - 60 * 2 - 30) // 2, 200
    for i, (label, value, chg) in enumerate(items):
        x0, y0 = 60 + (i % 2) * (tw + 30), y + (i // 2) * (th + 30)
        cv.panel(x0, y0, x0 + tw, y0 + th)
        cv.text((x0 + 30, y0 + 34), label.upper() if cv.retro else label, 30, "SemiBold", cv.c["muted"])
        cv.text((x0 + 30, y0 + 92), value, 74 if cv.retro else 64, "Bold", _col(cv, chg),
                role="display" if cv.retro else None)
    return y + ((len(items) + 1) // 2) * (th + 30)


def _table(cv: Canvas, y, cols: list[str], rows: list[list[tuple[str, str | None]]], widths: list[int]):
    x = 60
    for c, w in zip(cols, widths):
        cv.text((x, y), c.upper() if cv.retro else c, 28, "SemiBold", cv.c["accent"] if cv.retro else cv.c["muted"])
        x += w
    y += 58
    for r in rows:
        cv.d.line((60, y - 14, W - 60, y - 14), fill=cv.c["line"], width=2)
        x = 60
        for i, ((val, color), w) in enumerate(zip(r, widths)):
            cv.text((x, y), val, 40, "Bold" if i == 0 else "Regular", color)
            x += w
        y += 88
    return y


def _mpl_font():
    fonts = THEME.get("fonts")
    if not fonts:
        return {}
    for role in ("body", "bold"):
        font_manager.fontManager.addfont(str(ROOT / fonts[role]))
    return {"family": font_manager.FontProperties(fname=str(ROOT / fonts["body"])).get_name()}


def _chart_moves(cv: Canvas, rows: list[dict], path: Path, actual_key: str | None = None):
    """Paired bars: options-implied move vs the stock's usual (or actual) move."""
    c, ff = cv.c, _mpl_font()
    rows = rows[:8]
    names = [r["symbol"] for r in rows][::-1]
    imp = [(r.get("implied") or {}).get("implied_move_pct") or r.get("implied_move_pct") or 0 for r in rows][::-1]
    other = [r["history"]["avg_move_pct"] if not actual_key else r[actual_key] for r in rows][::-1]
    fig, ax = plt.subplots(figsize=(9.6, 1.15 * len(rows) + 1.2), dpi=100)
    fig.patch.set_facecolor(c["bg"])
    ax.set_facecolor(c["bg"])
    ys = range(len(names))
    a_col, b_col = (c["accent"], c["text"]) if cv.retro else (c["accent"], c["muted"])
    ax.barh([y + 0.2 for y in ys], imp, height=0.38, color=a_col, label="Options-implied move")
    ax.barh([y - 0.2 for y in ys], other, height=0.38, color=b_col, alpha=0.75 if cv.retro else 1,
            label="Actual move" if actual_key else "Average past move")
    for y, a, b in zip(ys, imp, other):
        ax.text(a + 0.2, y + 0.2, f"\u00b1{a:.1f}%", va="center", color=a_col, fontsize=16, fontweight="bold", **ff)
        ax.text(b + 0.2, y - 0.2, f"{b:.1f}%", va="center", color=b_col, fontsize=15, **ff)
    ax.set_yticks(list(ys), names, color=c["text"], fontsize=19, fontweight="bold", **ff)
    ax.tick_params(axis="x", colors=c["muted"], labelsize=12)
    ax.tick_params(axis="y", length=0)
    if cv.retro:
        ax.grid(axis="x", color=c["line"], linewidth=1)
        ax.set_axisbelow(True)
    for s in ax.spines.values():
        s.set_visible(False)
    ax.set_xlim(0, max(imp + other) * 1.32)
    leg = ax.legend(loc="lower right", frameon=False, labelcolor=c["text"], fontsize=13, prop=ff or None)
    if ff:
        for t in leg.get_texts():
            t.set_fontsize(13)
    fig.tight_layout()
    fig.savefig(path, facecolor=c["bg"])
    plt.close(fig)
    return path


def _chart_pairs(cv: Canvas, names, a, b, a_label, b_label, path: Path, fmt=lambda v: f"{v:.1f}"):
    """Generic paired horizontal bars (e.g. forward P/E vs 5-year median). None values are skipped."""
    c, ff = cv.c, _mpl_font()
    names, a, b = names[::-1], [x or 0 for x in a][::-1], [x or 0 for x in b][::-1]
    fig, ax = plt.subplots(figsize=(9.6, 1.05 * len(names) + 1.2), dpi=100)
    fig.patch.set_facecolor(c["bg"]); ax.set_facecolor(c["bg"])
    ys = range(len(names))
    ax.barh([y + 0.2 for y in ys], a, height=0.38, color=c["accent"], label=a_label)
    ax.barh([y - 0.2 for y in ys], b, height=0.38, color=c["text"], alpha=0.7, label=b_label)
    for y, va, vb in zip(ys, a, b):
        if va:
            ax.text(va + max(a + b) * 0.01, y + 0.2, fmt(va), va="center", color=c["accent"], fontsize=15, fontweight="bold", **ff)
        if vb:
            ax.text(vb + max(a + b) * 0.01, y - 0.2, fmt(vb), va="center", color=c["text"], fontsize=14, **ff)
    ax.set_yticks(list(ys), names, color=c["text"], fontsize=19, fontweight="bold", **ff)
    ax.tick_params(axis="x", colors=c["muted"], labelsize=12); ax.tick_params(axis="y", length=0)
    ax.grid(axis="x", color=c["line"], linewidth=1); ax.set_axisbelow(True)
    for sp in ax.spines.values():
        sp.set_visible(False)
    ax.set_xlim(0, max(a + b) * 1.25)
    ax.legend(loc="lower right", frameon=False, labelcolor=c["text"], prop=ff or None)
    fig.tight_layout(); fig.savefig(path, facecolor=c["bg"]); plt.close(fig)
    return path


def _chart_diverging(cv: Canvas, names, vals, path: Path, unit=" pts"):
    """Signed bars about zero, green above / red below (relative performance)."""
    c, ff = cv.c, _mpl_font()
    names, vals = names[::-1], vals[::-1]
    fig, ax = plt.subplots(figsize=(9.6, 0.62 * len(names) + 1.0), dpi=100)
    fig.patch.set_facecolor(c["bg"]); ax.set_facecolor(c["bg"])
    ys = range(len(names))
    ax.barh(list(ys), vals, height=0.62, color=[c["up"] if v >= 0 else c["down"] for v in vals])
    lim = max(abs(v) for v in vals) * 1.45
    for y, v in zip(ys, vals):
        ax.text(v + (lim * 0.02 if v >= 0 else -lim * 0.02), y, f"{v:+.1f}{unit}", va="center",
                ha="left" if v >= 0 else "right", color=c["text"], fontsize=13, **ff)
    ax.set_yticks(list(ys), names, color=c["text"], fontsize=15, **ff)
    ax.axvline(0, color=c["muted"], linewidth=1.2)
    ax.tick_params(axis="x", colors=c["muted"], labelsize=11); ax.tick_params(axis="y", length=0)
    for sp in ax.spines.values():
        sp.set_visible(False)
    ax.set_xlim(-lim, lim)
    fig.tight_layout(); fig.savefig(path, facecolor=c["bg"]); plt.close(fig)
    return path


def _paste(cv: Canvas, img_path: Path, y: int) -> int:
    im = Image.open(img_path)
    cv.img.paste(im, (60, y))
    return y + im.height


def _session(s):
    return {"bmo": "pre-mkt", "amc": "post-mkt"}.get(s, "tbc") if THEME.get("fonts") else \
        {"bmo": "before open", "amc": "after close"}.get(s, "time tbc")


# ---------------------------------------------------------------- ticker tape

def ticker_items(payload: dict) -> list[tuple[str, float | None, float | None]]:
    """(symbol, price, change %) for the tape, taken from whatever the payload holds."""
    out = []
    for k, v in (payload.get("indices") or {}).items():
        out.append((k, v.get("last"), v.get("change_pct")))
    for r in payload.get("earnings_today", []) + payload.get("earnings", []):
        out.append((r["symbol"], r.get("spot"), None))
    for u in payload.get("unusual", []):
        out.append((u["symbol"], u.get("spot"), None))
    for k, v in (payload.get("index_week_pct") or {}).items():
        out.append((k + " WK", None, v))
    for r in payload.get("results", []):
        out.append((r["symbol"], r.get("spot"), r.get("move_pct")))
    for r in payload.get("stocks", []):
        out.append((r["symbol"] + " FWD P/E", r.get("fwd_pe"), None))
    for r in payload.get("top", []) + payload.get("weakest", []):
        out.append((r["symbol"] + " YLD", r.get("yield_pct"), None))
    for r in payload.get("etfs", []):
        out.append((r["symbol"], None, r.get("rel_m1")))
    if payload.get("quote"):
        q = payload["quote"]
        out.insert(0, (payload["symbol"], q.get("last"), q.get("change_pct")))
    return out


def build_tape(payload: dict, out: Path) -> Path | None:
    items = ticker_items(payload)
    if not items or not THEME.get("effects", {}).get("ticker"):
        return None
    c = THEME["colors"]
    f = _font(52, role="display")
    parts = []
    for sym, px, chg in items:
        txt = f"{sym}" + (f" {px:,.2f}" if px else "") + (f" {chg:+.1f}%" if chg is not None else "")
        parts.append((txt, c["text"] if chg is None else c["up"] if chg >= 0 else c["down"]))
    sep = "   \u2022   "
    one = sum(f.getlength(t) + f.getlength(sep) for t, _ in parts)
    reps = max(2, int(W * 3 / one) + 2)
    strip = Image.new("RGB", (int(one * reps) + 10, TICKER_H - 4), c["tape_bg"])
    d = ImageDraw.Draw(strip)
    x = 0
    for _ in range(reps):
        for t, col in parts:
            d.text((x, (TICKER_H - 4) // 2), t, font=f, fill=col, anchor="lm")
            x += f.getlength(t)
            d.text((x, (TICKER_H - 4) // 2), sep, font=f, fill=c["accent"], anchor="lm")
            x += f.getlength(sep)
    strip = crt(strip)
    p = out / "tape.png"
    strip.save(p)
    (out / "tape.json").write_text(json.dumps({"loop_px": one}))
    return p


# ---------------------------------------------------------------- per-show visuals

def build_frames(script: dict, payload: dict, cfg: dict, out: Path) -> list[tuple[str, Path]]:
    show, sec = payload["show"], script["sections"]
    frames = []

    def new(headline, subtitle=""):
        cv = Canvas(cfg)
        return cv, cv.frame(headline, subtitle)

    def done(cv, key):
        cv.caption(sec.get(key, ""))
        p = out / f"{len(frames):02d}_{key}.png"
        cv.save(p)
        frames.append((key, p))

    def hook_frame(sub, banner=None):
        cv, y = new("", sub)
        c = cv.c
        top = 640
        if banner:
            cv.d.rectangle((60, top - 150, W - 60, top - 40), fill=c["down"])
            cv.text((W // 2, top - 95), banner, 84 if cv.retro else 64, "Bold", "#000000", anchor="mm",
                    role="display" if cv.retro else None)
        else:
            cv.d.rectangle((60, top - 60, 220, top - 48), fill=c["accent"])
        if cv.retro:
            y = cv.wrapped(60, top, sec["hook"].upper(), 150, role="display", max_px=W - 120, gap=0.9, max_lines=6)
            cv.d.rectangle((64, y + 20, 124, y + 120), fill=c["accent"])  # blinking-cursor block
        else:
            cv.wrapped(72, top + 60, sec["hook"], 104, "Black", gap=1.08)
        p = out / f"{len(frames):02d}_hook.png"
        cv.save(p)
        frames.append(("hook", p))

    c = THEME["colors"]

    if show == "daily":
        hook_frame(date.fromisoformat(payload["date"]).strftime("%A %d %B %Y"))
        ix = payload["indices"]
        cv, y = new("Before the bell", "US index trackers, % change")
        labels = {"SPY": "S&P 500", "QQQ": "Nasdaq 100", "DIA": "Dow", "IWM": "Russell 2000"}
        items = [(labels.get(k, k), _pct(v.get("change_pct")), v.get("change_pct")) for k, v in ix.items() if k != "VIX"]
        if "VIX" in ix:
            items.append(("VIX", f"{ix['VIX']['last']:.1f}", -(ix["VIX"].get("change_pct") or 0)))
        _tiles(cv, y, items)
        done(cv, "indices")
        cv, y = new("Today's data", "UK time, consensus estimate")
        rows = [[(e["time"][11:16] if e.get("time") else "", c["muted"]), (e["country"], c["accent"]),
                 (e["event"][:18] + ("\u2026" if len(e["event"]) > 18 else ""), None), (str(e.get("estimate", "")), None)]
                for e in payload["economic_calendar"][:6]]
        _table(cv, y, ["Time", "", "Event", "Est."], rows or [[("No major data today", c["muted"])]], [140, 90, 560, 170])
        done(cv, "macro")
        cv, y = new("Reporting today", "Options-implied move vs usual move")
        rows = [[(e["symbol"], None), (_session(e["session"]), c["muted"]),
                 ("\u00b1" + _pct(e["implied"]["implied_move_pct"], False) if e.get("implied") else "n/a", c["accent"]),
                 (_pct(e["history"]["avg_move_pct"], False), c["muted"])] for e in payload["earnings_today"]]
        _table(cv, y, ["Stock", "When", "Implied", "Usual"], rows or [[("None in our list", c["muted"])]], [220, 280, 260, 200])
        done(cv, "earnings")
        cv, y = new("Also moving")
        for h in script.get("news_headlines", [])[:3]:
            cv.panel(60, y, W - 60, y + 200)
            cv.wrapped(96, y + 34, ("> " if cv.retro else "") + h, 38, "SemiBold", max_px=W - 200, max_lines=3)
            y += 230
        done(cv, "news")

    elif show == "weekly":
        s, e = date.fromisoformat(payload["week_start"]), date.fromisoformat(payload["week_end"])
        hook_frame(f"Earnings week ahead \u00b7 {s:%d %b} to {e:%d %b}")
        cv, y = new("What options are pricing", "Implied earnings move vs average past move")
        _paste(cv, _chart_moves(cv, sorted(payload["earnings"], key=lambda r: r["date"]), out / "chart_board.png"), y)
        done(cv, "board")
        cv, y = new("Rich or cheap?", "Implied move divided by usual move")
        rows = [[(r["symbol"], None), (date.fromisoformat(r["date"]).strftime("%a"), c["muted"]),
                 (f"{r['ratio']:.2f}x" if r.get("ratio") else "n/a", None),
                 (r["verdict"], c["down"] if r["verdict"] == "rich" else c["up"] if r["verdict"] == "cheap" else c["muted"])]
                for r in sorted(payload["earnings"], key=lambda r: -(r.get("ratio") or 0))]
        _table(cv, y, ["Stock", "Day", "Ratio", "Options look"], rows, [220, 150, 230, 360])
        done(cv, "standouts")
        cv, y = new("Also next week")
        rows = [[(date.fromisoformat(ev["time"][:10]).strftime("%a"), c["muted"]), (ev["country"], c["accent"]),
                 (ev["event"][:24] + ("\u2026" if len(ev["event"]) > 24 else ""), None)] for ev in payload["economic_calendar"][:7]]
        _table(cv, y, ["Day", "", "Event"], rows or [[("Quiet week", c["muted"])]], [140, 90, 730])
        done(cv, "macro")

    elif show == "radar":
        u = payload["unusual"]
        hook_frame(f"Unusual options activity \u00b7 {date.fromisoformat(payload['date']):%d %b %Y}")
        for i, ct in enumerate(u[:3], 1):
            key = f"contract_{i}"
            cv, y = new(f"{ct['symbol']} ${ct['strike']:g} {ct['option_type']}s",
                        f"Expiry {date.fromisoformat(ct['expiry']):%d %b} \u00b7 {ct['dte']} days")
            y = _tiles(cv, y, [("Premium paid", f"${ct['premium_usd'] / 1e6:.1f}m", 1),
                               ("Vol / open int.", f"{ct['vol_oi']:.1f}x", 1),
                               ("Share price", f"${ct['spot']:.2f}", None),
                               ("Break-even", f"${ct['breakeven']:.2f}", 1 if ct["option_type"] == "call" else -1)])
            cv.wrapped(60, y + 10, f"Needs a {abs((ct['breakeven'] / ct['spot'] - 1) * 100):.1f}% move "
                       f"{'up' if ct['option_type'] == 'call' else 'down'} by expiry", 36, "SemiBold", c["muted"])
            done(cv, key)

    elif show == "alert":
        q = payload.get("quote") or {}
        sym = payload.get("symbol")
        chg = q.get("change_pct")
        hook_frame(datetime.fromisoformat(payload["detected_at"]).strftime("%d %b %Y \u00b7 %H:%M GMT"), banner="BREAKING")
        if sym:
            cv, y = new(f"{sym} {_pct(chg)}", payload.get("company") or "")
            vol_x = (q["volume"] / q["average_volume"]) if q.get("volume") and q.get("average_volume") else None
            _tiles(cv, y, [("Last price", f"${q['last']:,.2f}", chg), ("Today", _pct(chg), chg),
                           ("Day range", f"{q.get('low', 0):,.0f}-{q.get('high', 0):,.0f}", None),
                           ("Volume vs avg", f"{vol_x:.1f}x" if vol_x else "n/a", 1)])
        else:
            cv, y = new("Markets react", "US index trackers, % change")
            _tiles(cv, y, [(k, _pct(v.get("change_pct")), v.get("change_pct")) for k, v in (payload.get("indices") or {}).items()])
        done(cv, "move")
        cv, y = new("What we know", "Headlines from news wires")
        for h, src in zip(script.get("news_headlines", [])[:3], payload.get("headlines", [])[:3]):
            cv.panel(60, y, W - 60, y + 230)
            yy = cv.wrapped(96, y + 30, ("> " if cv.retro else "") + h, 38, "SemiBold", max_px=W - 200, max_lines=3)
            cv.text((96, y + 190), (src.get("source") or "").upper(), 24, color=c["muted"])
            y += 260
        done(cv, "why")
        if sec.get("chatter"):
            cv, y = new("Chatter on X", "Unverified. Not confirmed by news wires.")
            cv.panel(60, y, W - 60, y + 360, outline=c["accent"])
            cv.wrapped(96, y + 36, sec["chatter"], 40, max_px=W - 200, max_lines=7)
            done(cv, "chatter")

    elif show == "reaction":
        rs = payload["results"]
        hook_frame(f"Earnings reaction \u00b7 {date.fromisoformat(payload['date']):%d %b %Y}")
        cv, y = new("Results vs estimates", "Surprise vs analyst consensus")
        sc = lambda v: (_pct(v), c["up"] if v >= 0 else c["down"]) if v is not None else ("n/a", c["muted"])
        rows = [[(r["symbol"], None), sc(r.get("eps_surprise_pct")), sc(r.get("rev_surprise_pct"))] for r in rs]
        _table(cv, y, ["Stock", "EPS", "Revenue"], rows or [[("No reports", c["muted"])]], [300, 330, 330])
        done(cv, "results")
        cv, y = new("Move vs implied", "Share move today vs what options priced")
        with_imp = [r for r in rs if r.get("implied_move_pct") and r.get("actual_move_pct") is not None]
        if with_imp:
            _paste(cv, _chart_moves(cv, with_imp, out / "chart_reaction.png", actual_key="actual_move_pct"), y)
        done(cv, "moves")

    elif show == "sector":
        sm = payload["summary"]
        hook_frame(f"Sector health check \u00b7 {payload['sector']}")
        cv, y = new(f"{payload['sector']}: valuation", f"Medians across {len(payload['stocks'])} stocks")
        vs = sm.get("vs_history_pct")
        _tiles(cv, y, [("Trailing P/E", f"{sm.get('median_pe_ttm') or 0:.1f}x", None),
                       ("Forward P/E", f"{sm.get('median_fwd_pe') or 0:.1f}x", None),
                       (f"{payload['history_years']}-yr median", f"{sm.get('median_hist_pe') or 0:.1f}x", None),
                       ("P/E vs history", f"{vs:+d}%" if vs is not None else "n/a", -(vs or 0))])
        done(cv, "valuation")
        cv, y = new("Each stock vs its own past", "Trailing P/E today vs its 5-year median")
        st = [x for x in payload["stocks"] if x.get("pe_ttm") and x.get("hist_pe_median")][:8]
        if st:
            _paste(cv, _chart_pairs(cv, [x["symbol"] for x in st], [x["pe_ttm"] for x in st],
                                    [x["hist_pe_median"] for x in st], "P/E today", "5-yr median P/E",
                                    out / "chart_sector.png", fmt=lambda v: f"{v:.0f}x"), y)
        done(cv, "standouts")

    elif show == "dividends":
        hook_frame(f"Dividend Kings \u00b7 50+ years of rises")
        cv, y = new("Best-covered dividends", "Cover score 0-100 (3-yr cash flow, earnings, debt, growth)")
        sc_col = lambda v: c["up"] if v >= 70 else c["accent"] if v >= 45 else c["down"]
        rows = [[(r["symbol"], None), (_pct(r["yield_pct"], False), None),
                 (_pct(r.get("fcf_payout_pct"), False, 0) if r.get("fcf_payout_pct") is not None else "n/a", c["muted"]),
                 (str(r["cover_score"]), sc_col(r["cover_score"]))] for r in payload["top"]]
        _table(cv, y, ["Stock", "Yield", "FCF paid", "Score"], rows, [220, 230, 300, 200])
        done(cv, "scorecard")
        cv, y = new("Thinnest cover", "Lowest scores among the Kings")
        rows = [[(r["symbol"], None), (_pct(r["yield_pct"], False), None),
                 (_pct(r.get("payout_pct"), False, 0) if r.get("payout_pct") is not None else "n/a", c["muted"]),
                 (str(r["cover_score"]), sc_col(r["cover_score"]))] for r in payload["weakest"]]
        y = _table(cv, y, ["Stock", "Yield", "EPS paid", "Score"], rows, [220, 230, 300, 200])
        cv.wrapped(60, y + 20, "Score: 40 pts dividend vs 3-yr free cash flow, 25 pts vs earnings, 20 pts net debt/EBITDA, "
                   "15 pts 5-yr dividend growth. A screen, not a recommendation.", 28, color=c["muted"])
        done(cv, "watch")

    elif show == "rotation":
        hook_frame(f"Theme rotation \u00b7 {date.fromisoformat(payload['date']):%d %b %Y}")
        cv, y = new("1 month vs S&P 500", "Relative performance, percentage points")
        e = payload["etfs"][:12]
        _paste(cv, _chart_diverging(cv, [x["label"] for x in e], [x["rel_m1"] for x in e], out / "chart_rotation.png"), y)
        done(cv, "leaders")
        cv, y = new("Momentum shifting", "Last month vs 3-month pace")
        rows = [[(x["label"], None), (f"{x['rel_m1']:+.1f}", _col(cv, x["rel_m1"])), (f"{x['rel_m3']:+.1f}", _col(cv, x["rel_m3"]))]
                for x in payload["turning_up"] + payload["turning_down"]]
        _table(cv, y, ["Theme", "1 month", "3 months"], rows, [480, 240, 240])
        done(cv, "laggards")

    else:  # recap
        hook_frame(f"Week of {date.fromisoformat(payload['week_of']):%d %B}")
        cv, y = new("This week", "US index trackers, % change on the week")
        _tiles(cv, y, [(k, _pct(v, nd=2), v) for k, v in payload["index_week_pct"].items()])
        done(cv, "indices")
        cv, y = new("Earnings vs the implied move")
        rows = [r for r in payload["earnings_results"] if r.get("implied_move_pct")]
        if rows:
            _paste(cv, _chart_moves(cv, rows, out / "chart_recap.png", actual_key="actual_move_pct"), y)
        done(cv, "earnings")

    cv = Canvas(cfg)
    if cv.retro:
        cv.frame("")
        cv.text((W // 2, 760), cfg["brand"]["name"].upper(), 120, role="display", color=c["accent"], anchor="ma")
        cv.text((W // 2, 900), "> FOLLOW FOR THE NEXT ONE_", 56, role="display", anchor="ma")
    else:
        cv.text((W // 2, 760), cfg["brand"]["name"], 84, "Black", anchor="ma")
        cv.text((W // 2, 880), "Follow for the next one", 52, "SemiBold", c["accent"], anchor="ma")
    cv.wrapped(W // 2, 1050, cfg["brand"]["disclaimer"] + " Data from market feeds; figures may be delayed.", 30,
               color=c["muted"], anchor="ma", max_px=W - 240)
    done(cv, "outro")
    return frames


# ---------------------------------------------------------------- audio + video

def _duration(path: Path) -> float:
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(path)],
                       capture_output=True, text=True, check=True)
    return float(r.stdout.strip())


def tts(text: str, path: Path, cfg: dict) -> Path | None:
    v = cfg["voice"]
    key = secret("ELEVENLABS_API_KEY")
    if v["provider"] != "elevenlabs" or not key or not text.strip():
        return None
    r = requests.post(f"https://api.elevenlabs.io/v1/text-to-speech/{v['voice_id']}", timeout=120,
                      headers={"xi-api-key": key, "accept": "audio/mpeg"},
                      json={"text": text, "model_id": v["model_id"],
                            "voice_settings": {"stability": v.get("stability", 0.6), "similarity_boost": 0.8,
                                               "speed": v.get("speed", 1.0)}})
    r.raise_for_status()
    path.write_bytes(r.content)
    return path


def render(script: dict, payload: dict, cfg: dict, out: Path) -> Path:
    if not shutil.which("ffmpeg"):
        raise RuntimeError("ffmpeg is required")
    set_theme(cfg)
    out.mkdir(parents=True, exist_ok=True)
    frames = build_frames(script, payload, cfg, out)
    tape = build_tape(payload, out)
    clip = broll.pick(cfg, payload)
    data_keys = [k for k, _ in frames if k not in ("hook", "outro")]
    cuts = dict(zip(data_keys, broll.cutaway_clips(cfg, payload, len(data_keys))))
    cut_s = cfg.get("broll", {}).get("cutaway_seconds", 1.0)
    speed = THEME.get("effects", {}).get("ticker_speed", 160)
    grain = THEME.get("effects", {}).get("grain")
    wps = cfg["writer"]["reading_speed_wps"]
    segs, t0 = [], 0.0
    for key, img in frames:
        vo = script["sections"].get(key, "")
        recorded = out / f"vo_{key}.mp3"  # voice.provider: file -> drop your own recordings here
        audio = recorded if recorded.exists() else tts(vo, out / f"tts_{key}.mp3", cfg)
        dur = (_duration(audio) + cfg["voice"].get("pause_between_sections", 0.35)) if audio else max(2.5, len(vo.split()) / wps + 0.5)
        seg = out / f"seg_{key}.mp4"
        cmd = ["ffmpeg", "-y", "-loglevel", "error", "-loop", "1", "-i", str(img)]
        cmd += ["-i", str(audio)] if audio else ["-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo"]
        chain, last = [], "[0:v]"
        nxt = 2
        if clip and key in ("hook", "outro"):
            # retro footage behind the text: key out the dark background of the frame
            cmd += ["-stream_loop", "-1", "-i", str(clip)]
            chain.append(broll.bg_filter(nxt, cfg, THEME))
            key_col = THEME["colors"]["bg"].lstrip("#")
            chain.append(f"[0:v]colorkey=0x{key_col}:0.16:0.08[fg]")
            chain.append("[bg][fg]overlay=0:0[base]")
            last, nxt = "[base]", nxt + 1
        elif key in cuts:
            # 1-second cutaway: footage over the card at the start, then the data appears
            cmd += ["-i", str(cuts[key])]
            chain.append(broll.bg_filter(nxt, cfg, THEME).replace("[bg]", "[cut]"))
            chain.append(f"{last}[cut]overlay=0:0:enable='lt(t,{cut_s})'[withcut]")
            last, nxt = "[withcut]", nxt + 1
        if tape:
            # the tape keeps scrolling across cuts because each segment starts at its running offset t0
            loop = json.loads((out / "tape.json").read_text())["loop_px"]
            cmd += ["-loop", "1", "-i", str(tape)]
            chain.append(f"{last}[{nxt}:v]overlay=x='-mod((t+{t0:.2f})*{speed}\\,{loop:.0f})':y={TICKER_Y + 2}[taped]")
            last, nxt = "[taped]", nxt + 1
        fx = "fade=t=in:st=0:d=0.2" + (",noise=alls=5:allf=t" if grain else "") + ",format=yuv420p"
        chain.append(f"{last}{fx}[v]")
        cmd += ["-filter_complex", ";".join(chain), "-map", "[v]", "-map", "1:a", "-t", f"{dur:.2f}", "-r", "30",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-c:a", "aac", "-ar", "44100", "-ac", "2", str(seg)]
        subprocess.run(cmd, check=True)
        segs.append(seg)
        t0 += dur
    lst = out / "segments.txt"
    lst.write_text("".join(f"file '{s.name}'\n" for s in segs))
    final = out / "video.mp4"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "concat", "-safe", "0", "-i", str(lst),
                    "-c", "copy", "-movflags", "+faststart", str(final)], check=True, cwd=out)
    return final
