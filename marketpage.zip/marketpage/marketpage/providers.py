"""Thin API clients. Each returns plain dicts so the rest of the code never sees vendor formats."""
from __future__ import annotations

import time
from datetime import date, datetime, timedelta, timezone

import requests

from .config import secret


class Tradier:
    """Quotes, options chains and daily history. https://documentation.tradier.com"""

    def __init__(self, base: str):
        self.base = base.rstrip("/")
        self.s = requests.Session()
        self.s.headers.update({"Authorization": f"Bearer {secret('TRADIER_TOKEN', True)}",
                               "Accept": "application/json"})

    def _get(self, path: str, **params) -> dict:
        for attempt in range(3):
            r = self.s.get(f"{self.base}{path}", params=params, timeout=20)
            if r.status_code == 429:
                time.sleep(2 ** attempt)
                continue
            r.raise_for_status()
            return r.json()
        r.raise_for_status()
        return {}

    @staticmethod
    def _as_list(x):
        return [] if x is None else x if isinstance(x, list) else [x]

    def quotes(self, symbols: list[str]) -> dict[str, dict]:
        data = self._get("/markets/quotes", symbols=",".join(symbols))
        qs = self._as_list((data.get("quotes") or {}).get("quote"))
        return {q["symbol"]: {"last": q.get("last"), "prevclose": q.get("prevclose"),
                              "change_pct": q.get("change_percentage"), "volume": q.get("volume"),
                              "average_volume": q.get("average_volume"), "high": q.get("high"),
                              "low": q.get("low"), "description": q.get("description")} for q in qs}

    def expirations(self, symbol: str) -> list[str]:
        data = self._get("/markets/options/expirations", symbol=symbol, includeAllRoots="true")
        return self._as_list((data.get("expirations") or {}).get("date"))

    def chain(self, symbol: str, expiry: str) -> list[dict]:
        data = self._get("/markets/options/chains", symbol=symbol, expiration=expiry, greeks="false")
        return self._as_list((data.get("options") or {}).get("option"))

    def closes(self, symbol: str, start: date, end: date) -> dict[str, float]:
        data = self._get("/markets/history", symbol=symbol, interval="daily",
                         start=start.isoformat(), end=end.isoformat())
        days = self._as_list((data.get("history") or {}).get("day"))
        return {d["date"]: d["close"] for d in days}


class Finnhub:
    """Earnings calendar and general news. https://finnhub.io/docs/api"""

    def __init__(self, base: str):
        self.base = base.rstrip("/")
        self.key = secret("FINNHUB_KEY", True)

    def _get(self, path: str, **params):
        params["token"] = self.key
        r = requests.get(f"{self.base}{path}", params=params, timeout=20)
        r.raise_for_status()
        time.sleep(1.05)  # free tier: 60 calls per minute
        return r.json()

    def earnings(self, start: date, end: date, symbol: str | None = None) -> list[dict]:
        params = {"from": start.isoformat(), "to": end.isoformat()}
        if symbol:
            params["symbol"] = symbol
        rows = self._get("/calendar/earnings", **params).get("earningsCalendar", [])
        return [{"symbol": r["symbol"], "date": r["date"], "session": (r.get("hour") or "").lower(),
                 "eps_estimate": r.get("epsEstimate"), "revenue_estimate": r.get("revenueEstimate"),
                 "eps_actual": r.get("epsActual"), "revenue_actual": r.get("revenueActual")}
                for r in rows]

    def market_cap(self, symbol: str) -> float | None:
        p = self._get("/stock/profile2", symbol=symbol)
        return (p.get("marketCapitalization") or 0) * 1e6 or None  # Finnhub reports $m

    def company_news(self, symbol: str, day: date) -> list[dict]:
        rows = self._get("/company-news", symbol=symbol, **{"from": day.isoformat(), "to": day.isoformat()})
        return [{"title": r["headline"], "summary": r.get("summary", ""), "source": r.get("source"),
                 "url": r.get("url"), "published": datetime.fromtimestamp(r["datetime"], timezone.utc).isoformat()}
                for r in sorted(rows, key=lambda r: -r["datetime"])]

    def news(self) -> list[dict]:
        rows = self._get("/news", category="general")
        return [{"title": r["headline"], "summary": r.get("summary", ""), "source": r.get("source"),
                 "url": r.get("url"), "published": datetime.fromtimestamp(r["datetime"], timezone.utc).isoformat()}
                for r in rows]


def econ_calendar(url: str, start: date, end: date, countries: list[str], min_impact: str) -> list[dict]:
    """Economic calendar (FMP). Field names vary by plan, so map defensively."""
    key = secret("FMP_KEY")
    if not key:
        return []
    r = requests.get(url, params={"from": start.isoformat(), "to": end.isoformat(), "apikey": key}, timeout=20)
    r.raise_for_status()
    out = []
    for e in r.json():
        if e.get("country") not in countries:
            continue
        if min_impact and (e.get("impact") or "").lower() != min_impact.lower():
            continue
        out.append({"time": e.get("date"), "country": e.get("country"), "event": e.get("event"),
                    "estimate": e.get("estimate"), "previous": e.get("previous"), "actual": e.get("actual")})
    return out


def rss_news(feeds: list[str], lookback_hours: int, max_items: int) -> list[dict]:
    import feedparser

    cutoff = datetime.now(timezone.utc) - timedelta(hours=lookback_hours)
    items = []
    for url in feeds:
        for e in feedparser.parse(url).entries:
            ts = e.get("published_parsed") or e.get("updated_parsed")
            when = datetime(*ts[:6], tzinfo=timezone.utc) if ts else None
            if when and when < cutoff:
                continue
            items.append({"title": e.get("title", "").strip(), "summary": e.get("summary", "")[:400],
                          "source": url.split("/")[2], "url": e.get("link"),
                          "published": when.isoformat() if when else None})
    seen, unique = set(), []
    for it in items:  # drop near-duplicate headlines
        k = it["title"].lower()[:60]
        if k not in seen:
            seen.add(k)
            unique.append(it)
    return unique[:max_items]


def grok_x_search(question: str, model: str, hours: int = 6) -> dict:
    """Ask Grok to search X (server-side x_search tool on xAI's Responses API).

    Returns {"summary": str, "citations": [url]}. Treated as unverified chatter everywhere downstream.
    """
    key = secret("XAI_API_KEY")
    if not key:
        return {}
    since = (datetime.now(timezone.utc) - timedelta(hours=hours)).date().isoformat()
    prompt = (f"{question}\nSearch X posts from the last {hours} hours. Summarise in 2 short sentences what "
              "people are saying, separating confirmed reports (with the account) from rumour. "
              "No price predictions. If nothing credible, say so.")
    r = requests.post("https://api.x.ai/v1/responses", timeout=180,
                      headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                      json={"model": model, "input": [{"role": "user", "content": prompt}],
                            "tools": [{"type": "x_search", "from_date": since}]})
    r.raise_for_status()
    data = r.json()
    text, cites = "", list(data.get("citations") or [])
    for item in data.get("output", []):
        if item.get("type") == "message":
            for part in item.get("content", []):
                text += part.get("text", "")
                cites += [a.get("url") for a in part.get("annotations", []) if a.get("url")]
    return {"summary": text.strip(), "citations": sorted(set(c for c in cites if c))[:8]}


class MarketData:
    """MarketData.app for options chains and daily candles; Finnhub's free quote endpoint for live prices.

    Same methods as Tradier, so the rest of the code doesn't care which one is configured.
    Credits: chains bill ~1 credit per contract returned, so every chain call is filtered
    (one expiry + a few strikes for implied moves; min volume for the options radar).
    """

    BASE = "https://api.marketdata.app/v1"

    def __init__(self, finnhub_base: str):
        self.s = requests.Session()
        self.s.headers.update({"Authorization": f"Bearer {secret('MARKETDATA_TOKEN', True)}",
                               "Accept": "application/json"})
        self.fh_base = finnhub_base.rstrip("/")

    def _get(self, path: str, **params) -> dict:
        for attempt in range(3):
            r = self.s.get(f"{self.BASE}{path}", params=params, timeout=30)
            if r.status_code == 429:
                time.sleep(5 * (attempt + 1))
                continue
            if r.status_code == 404:  # MarketData returns 404 + s=no_data when nothing matches
                return {"s": "no_data"}
            r.raise_for_status()
            return r.json()
        r.raise_for_status()
        return {}

    @staticmethod
    def _rows(d: dict) -> list[dict]:
        """MarketData returns column arrays; turn them into one dict per row."""
        if d.get("s") != "ok":
            return []
        cols = {k: v for k, v in d.items() if isinstance(v, list)}
        n = max((len(v) for v in cols.values()), default=0)
        return [{k: (v[i] if i < len(v) else None) for k, v in cols.items()} for i in range(n)]

    @staticmethod
    def _day(x) -> str:
        if isinstance(x, (int, float)):
            return datetime.fromtimestamp(x, timezone.utc).date().isoformat()
        return str(x)[:10]

    # live quotes through Finnhub (free, 60 calls/min) so MarketData credits go on options
    def quotes(self, symbols: list[str]) -> dict[str, dict]:
        key = secret("FINNHUB_KEY", True)
        out = {}
        for sym in symbols:
            r = requests.get(f"{self.fh_base}/quote", params={"symbol": sym, "token": key}, timeout=15)
            time.sleep(1.05)
            if r.status_code != 200:
                continue
            q = r.json()
            if not q.get("c"):
                continue
            out[sym] = {"last": q["c"], "prevclose": q.get("pc"), "change_pct": q.get("dp"),
                        "high": q.get("h"), "low": q.get("l"), "volume": None, "average_volume": None,
                        "description": None}
        return out

    def expirations(self, symbol: str) -> list[str]:
        d = self._get(f"/options/expirations/{symbol}/")
        return sorted(self._day(e) for e in d.get("expirations", []))

    def _contracts(self, d: dict) -> list[dict]:
        return [{"underlying": r.get("underlying"), "strike": r.get("strike"), "option_type": r.get("side"),
                 "expiration": self._day(r.get("expiration")), "bid": r.get("bid"), "ask": r.get("ask"),
                 "last": r.get("last"), "volume": r.get("volume") or 0, "open_interest": r.get("openInterest") or 0,
                 "iv": r.get("iv")} for r in self._rows(d)]

    def chain(self, symbol: str, expiry: str, strike_limit: int | None = 4) -> list[dict]:
        params = {"expiration": expiry}
        if strike_limit:
            params["strikeLimit"] = strike_limit
        return self._contracts(self._get(f"/options/chain/{symbol}/", **params))

    def chain_window(self, symbol: str, start: date, end: date, min_volume: int) -> list[dict]:
        """All contracts expiring in a date window that traded at least min_volume (for the radar)."""
        return self._contracts(self._get(f"/options/chain/{symbol}/", **{
            "from": start.isoformat(), "to": end.isoformat(), "minVolume": min_volume}))

    def closes(self, symbol: str, start: date, end: date) -> dict[str, float]:
        d = self._get(f"/stocks/candles/D/{symbol}/", **{"from": start.isoformat(), "to": end.isoformat()})
        return {self._day(r["t"]): r["c"] for r in self._rows(d) if r.get("c") is not None}


def market(cfg: dict):
    """The configured provider for quotes, options and price history."""
    p = cfg["providers"]
    if p.get("market", "marketdata") == "tradier":
        return Tradier(p["tradier_base"])
    return MarketData(p["finnhub_base"])
