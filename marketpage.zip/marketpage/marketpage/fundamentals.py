"""Valuation, dividend and rotation data.

Fundamentals come from Financial Modeling Prep's /stable API (Starter plan or above).
FMP renames fields now and then, so every field is read through _pick() with fallbacks.
"""
from __future__ import annotations

import time
from datetime import date, timedelta
from statistics import median

import requests

from .config import secret

FMP = "https://financialmodelingprep.com/stable"


def _get(path: str, **params):
    params["apikey"] = secret("FMP_KEY", True)
    for attempt in range(3):
        r = requests.get(f"{FMP}/{path}", params=params, timeout=30)
        if r.status_code == 429:
            time.sleep(5 * (attempt + 1))
            continue
        r.raise_for_status()
        return r.json()
    return []


def _pick(row: dict, *keys):
    for k in keys:
        v = row.get(k)
        if v not in (None, "", 0):
            return v
    return None


def _first(rows):
    return rows[0] if isinstance(rows, list) and rows else (rows if isinstance(rows, dict) else {})


# ---------------------------------------------------------------- valuation

def valuation(symbol: str, years: int = 5) -> dict:
    """Trailing P/E, forward P/E and the stock's own median P/E over recent fiscal years."""
    quote = _first(_get("quote", symbol=symbol))
    price = _pick(quote, "price")
    ttm = _first(_get("ratios-ttm", symbol=symbol))
    pe_ttm = _pick(ttm, "priceToEarningsRatioTTM", "peRatioTTM", "priceEarningsRatioTTM")
    hist = _get("ratios", symbol=symbol, period="annual", limit=years)
    pes = [p for p in (_pick(r, "priceToEarningsRatio", "priceEarningsRatio", "peRatio") for r in hist)
           if p and 0 < p < 400]
    est = _get("analyst-estimates", symbol=symbol, period="annual", limit=6)
    this_year = date.today().year
    fwd_eps = None
    for e in sorted(est, key=lambda e: e.get("date", "")):
        if e.get("date", "")[:4] >= str(this_year + (1 if date.today().month >= 7 else 0)):
            fwd_eps = _pick(e, "epsAvg", "estimatedEpsAvg")
            break
    fwd_pe = round(price / fwd_eps, 1) if price and fwd_eps and fwd_eps > 0 else None
    hist_med = round(median(pes), 1) if pes else None
    # like for like: today's trailing P/E against the median of past trailing P/Es (forward P/E shown alongside)
    cur = pe_ttm
    return {"symbol": symbol, "price": price, "pe_ttm": round(pe_ttm, 1) if pe_ttm else None,
            "fwd_pe": fwd_pe, "hist_pe_median": hist_med, "hist_years": len(pes),
            "vs_history_pct": round((cur / hist_med - 1) * 100) if cur and hist_med else None,
            "market_cap": _pick(quote, "marketCap")}


def sector_health(name: str, symbols: list[str], years: int) -> dict:
    rows = []
    for s in symbols:
        try:
            rows.append(valuation(s, years))
        except Exception as exc:  # one bad ticker shouldn't sink the show
            print("valuation failed", s, exc)
    ok = [r for r in rows if r.get("fwd_pe") or r.get("pe_ttm")]
    med = lambda k: round(median([r[k] for r in ok if r.get(k)]), 1) if any(r.get(k) for r in ok) else None
    summary = {"median_pe_ttm": med("pe_ttm"), "median_fwd_pe": med("fwd_pe"), "median_hist_pe": med("hist_pe_median")}
    if summary["median_pe_ttm"] and summary["median_hist_pe"]:
        summary["vs_history_pct"] = round((summary["median_pe_ttm"] / summary["median_hist_pe"] - 1) * 100)
    return {"sector": name, "stocks": sorted(ok, key=lambda r: -(r.get("market_cap") or 0)), "summary": summary,
            "history_years": years}


# ---------------------------------------------------------------- dividends

def dividend_profile(symbol: str) -> dict:
    """Yield, payout cover, balance sheet and 5-year dividend growth for one stock."""
    ttm = _first(_get("ratios-ttm", symbol=symbol))
    km = _first(_get("key-metrics-ttm", symbol=symbol))
    cf = _get("cash-flow-statement", symbol=symbol, period="annual", limit=3)
    divs = _get("dividends", symbol=symbol)
    yld = _pick(ttm, "dividendYieldTTM", "dividendYielTTM")
    payout = _pick(ttm, "dividendPayoutRatioTTM", "payoutRatioTTM")
    nd_ebitda = _pick(km, "netDebtToEBITDATTM")
    fcf_payout = None
    if cf:
        # 3-year totals, so one unusual year (a big tax or acquisition payment) doesn't swing the score
        paid = sum(abs(_pick(c, "commonDividendsPaid", "dividendsPaid", "netDividendsPaid") or 0) for c in cf)
        fcf = sum(_pick(c, "freeCashFlow") or 0 for c in cf)
        if paid and fcf > 0:
            fcf_payout = paid / fcf
    # 5-year dividend growth from per-share payments, by calendar year
    by_year: dict[int, float] = {}
    for d in divs if isinstance(divs, list) else []:
        y = int((d.get("date") or "0000")[:4] or 0)
        by_year[y] = by_year.get(y, 0) + (_pick(d, "adjDividend", "dividend") or 0)
    full = sorted(y for y in by_year if y < date.today().year)
    cagr = None
    if len(full) >= 6 and by_year[full[-6]] > 0:
        cagr = (by_year[full[-1]] / by_year[full[-6]]) ** (1 / 5) - 1
    pct = lambda x: round(x * 100, 1) if x is not None else None
    prof = {"symbol": symbol, "yield_pct": pct(yld), "payout_pct": pct(payout), "fcf_payout_pct": pct(fcf_payout),
            "net_debt_ebitda": round(nd_ebitda, 1) if nd_ebitda is not None else None, "div_cagr_5y_pct": pct(cagr)}
    prof["cover_score"] = cover_score(prof)
    return prof


def cover_score(p: dict) -> int | None:
    """0-100: how comfortably the dividend is covered. Transparent and shown on screen.

    40 pts free-cash-flow payout, 25 pts earnings payout, 20 pts net debt/EBITDA, 15 pts 5-yr growth.
    """
    if p.get("fcf_payout_pct") is None and p.get("payout_pct") is None:
        return None
    def band(x, good, bad, pts):
        if x is None:
            return pts / 2
        if x <= good:
            return pts
        if x >= bad:
            return 0
        return pts * (bad - x) / (bad - good)
    s = band(p.get("fcf_payout_pct"), 50, 100, 40) + band(p.get("payout_pct"), 50, 100, 25) + \
        band(p.get("net_debt_ebitda"), 1.5, 4.5, 20)
    g = p.get("div_cagr_5y_pct")
    s += 15 if g is None else max(0, min(15, g * 2.5))
    return round(s)


# ---------------------------------------------------------------- rotation

def returns_from_closes(closes: dict[str, float], today: date) -> dict:
    days = sorted(closes)
    if len(days) < 2:
        return {}
    last = closes[days[-1]]
    def ret(n_days):
        target = (today - timedelta(days=n_days)).isoformat()
        prior = [d for d in days if d <= target]
        return round((last / closes[prior[-1]] - 1) * 100, 1) if prior else None
    return {"w1": ret(7), "m1": ret(30), "m3": ret(91)}


def rotation(tr, etfs: dict[str, str], benchmark: str, today: date) -> dict:
    """Relative performance of sector/theme ETFs against the benchmark over 1 week, 1 and 3 months."""
    start = today - timedelta(days=100)
    bench = returns_from_closes(tr.closes(benchmark, start, today), today)
    rows = []
    for sym, label in etfs.items():
        try:
            r = returns_from_closes(tr.closes(sym, start, today), today)
        except Exception:
            continue
        if not r or r.get("m1") is None:
            continue
        rel = {k: round(r[k] - bench[k], 1) if r.get(k) is not None and bench.get(k) is not None else None for k in r}
        # momentum shift: last month's relative move versus the 3-month pace
        shift = round(rel["m1"] - rel["m3"] / 3, 1) if rel.get("m1") is not None and rel.get("m3") is not None else None
        rows.append({"symbol": sym, "label": label, **{f"ret_{k}": v for k, v in r.items()},
                     **{f"rel_{k}": v for k, v in rel.items()}, "shift": shift})
    rows.sort(key=lambda x: -(x.get("rel_m1") or -999))
    return {"benchmark": benchmark, "benchmark_returns": bench, "etfs": rows,
            "leaders": rows[:3], "laggards": rows[-3:][::-1],
            "turning_up": sorted([r for r in rows if r.get("shift") is not None], key=lambda r: -r["shift"])[:2],
            "turning_down": sorted([r for r in rows if r.get("shift") is not None], key=lambda r: r["shift"])[:2]}
