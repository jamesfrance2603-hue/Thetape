"""Script writer. The model writes words only; every figure on screen is drawn from the payload.

Providers: anthropic (Claude), xai (Grok), template (no AI, deterministic, used in demo/fallback).
"""
from __future__ import annotations

import json
import re

import requests

from .config import secret

SECTIONS = {
    "daily": ["hook", "indices", "macro", "earnings", "news", "outro"],
    "weekly": ["hook", "board", "standouts", "macro", "outro"],
    "radar": ["hook", "contract_1", "contract_2", "contract_3", "outro"],
    "recap": ["hook", "indices", "earnings", "outro"],
    "alert": ["hook", "move", "why", "chatter", "outro"],
    "reaction": ["hook", "results", "moves", "outro"],
    "sector": ["hook", "valuation", "standouts", "outro"],
    "dividends": ["hook", "scorecard", "watch", "outro"],
    "rotation": ["hook", "leaders", "laggards", "outro"],
}

STYLE = """You write voiceover scripts for a faceless markets page on TikTok and YouTube Shorts.
Rules, all mandatory:
- Report data. Never tell viewers to buy, sell, hold or trade anything. No price targets, no predictions stated as fact.
- Use ONLY numbers that appear in the DATA JSON. Round to 1 decimal place at most. If a number is not in DATA, do not say it.
- Options context: "implied move" is what options are pricing for the earnings reaction, either direction.
  ratio = implied move divided by the stock's average past earnings move; "rich" means options price more than usual.
- Unusual options activity reports what traded, not who traded it or why. Say "someone paid" or "traders bought", never claim insider knowledge.
- DATA.x_chatter is unverified talk on X found by search. You may describe it only as "chatter on X" or
  "posts on X claim", never as fact, never quote its numbers, and leave the "chatter" section empty if it adds nothing.
- DATA.headlines are news wire reports: state them as "reports say" with no added detail.
- For an alert with kind "earnings_swing": lead with the move against DATA.implied_move_pct (what options priced in).
- For an alert: lead with the move, then what the wires report. Never say why a stock moved unless a headline says so.
- reaction: say whether results beat or missed estimates and whether the share move was bigger or smaller than
  the options-implied move. Never say why investors reacted unless DATA says so.
- sector: compare today's trailing P/E with each stock's own 5-year median ("above its 5-year average"); forward
  P/E is extra context only, never compared with the historical median. Never call a
  stock or sector a buy, cheap-and-worth-buying or overvalued-and-to-avoid; describe, don't judge.
- dividends: describe how well each dividend is covered (cover score, payout of free cash flow, debt). Never say
  "safe to buy", "best to hold" or promise future dividends. Say "50-plus years of increases", not a precise count.
- rotation: describe relative performance against the S&P 500 tracker over 1 week, 1 month, 3 months; "money
  moving" language is fine as a description of relative performance, never as a prediction.
- Plain spoken British English, short sentences, no jargon without a 3-word explanation, no emoji, no hype words.
- Write like a calm, sharp business-news anchor: natural word order (who, what, how much), short sentences,
  everyday words. Read every line aloud in your head; if it sounds like a translation, rewrite it.
- Never start a sentence with a number. Use the % symbol, not the word "percent".
- Use the company name people know ("Super Micro", "Palantir"), not the ticker, in spoken lines.
- Each section is 1 to 3 sentences. The hook is one sentence under 12 words that puts the most striking fact up front.
  Good hooks: "Super Micro is down 14.6% today." / "Options price an 11.8% move in Palantir this week." /
  "Chip stocks now trade 34% above their five-year average." / "Utilities just beat the S&P 500 for a third month."
  Bad hooks (never write like this): "14.6 percent is the drop in Super Micro shares today." /
  "Implied move of 11.8% is what options show for PLTR." 
- Total spoken length {min_s} to {max_s} seconds at 2.6 words per second.
- The outro says "Follow for the next one" and nothing else promotional.
Return ONLY JSON: {{"title": str (max 80 chars), "caption": str (max 200 chars, ends with 'Not financial advice.'),
"hashtags": [str] (max 5), "news_headlines": [str] (daily: 3 headlines rewritten in your own words from DATA.news; alert: one per item in DATA.headlines, same order; else []),
"sections": {{{keys}}}}}"""

LENGTHS = {"daily": (60, 75), "weekly": (75, 110), "radar": (55, 70), "recap": (55, 70), "alert": (30, 50),
           "reaction": (50, 70), "sector": (60, 80), "dividends": (60, 80), "rotation": (55, 75)}


def _prompt(payload: dict) -> tuple[str, str]:
    show = payload["show"]
    keys = ", ".join(f'"{k}": str' for k in SECTIONS[show])
    mn, mx = LENGTHS[show]
    system = STYLE.format(min_s=mn, max_s=mx, keys=keys)
    data = {k: v for k, v in payload.items() if k != "demo"}
    if "news" in data:
        data["news"] = [{"title": n["title"], "summary": n.get("summary", "")[:200]} for n in data["news"][:25]]
    user = f"SHOW: {show}\nDATA:\n{json.dumps(data, default=str)}"
    return system, user


def _parse(text: str) -> dict:
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        raise ValueError("Model did not return JSON")
    return json.loads(m.group(0))


def _anthropic(system: str, user: str, cfg: dict) -> dict:
    r = requests.post("https://api.anthropic.com/v1/messages", timeout=120, headers={
        "x-api-key": secret("ANTHROPIC_API_KEY", True), "anthropic-version": "2023-06-01",
        "content-type": "application/json"}, json={
        "model": cfg["writer"]["model"], "max_tokens": cfg["writer"]["max_tokens"], "system": system,
        "messages": [{"role": "user", "content": user}]})
    r.raise_for_status()
    return _parse("".join(b.get("text", "") for b in r.json()["content"]))


def _xai(system: str, user: str, cfg: dict) -> dict:
    """Grok via xAI's OpenAI-compatible endpoint. Set writer.xai_model to a current model name."""
    r = requests.post("https://api.x.ai/v1/chat/completions", timeout=120, headers={
        "Authorization": f"Bearer {secret('XAI_API_KEY', True)}"}, json={
        "model": cfg["writer"].get("xai_model", "grok-4"), "max_tokens": cfg["writer"]["max_tokens"],
        "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]})
    r.raise_for_status()
    return _parse(r.json()["choices"][0]["message"]["content"])


def _f(x, nd=1):
    return f"{x:.{nd}f}".rstrip("0").rstrip(".") if isinstance(x, float) else str(x)


def template(payload: dict) -> dict:
    """No-AI script. Dull but always correct; used for demos and if the model call fails."""
    show, s = payload["show"], {}
    if show == "daily":
        ix = payload["indices"]
        s["hook"] = f"Nasdaq futures proxy {'up' if ix['QQQ']['change_pct'] >= 0 else 'down'} {_f(abs(ix['QQQ']['change_pct']))}% before the open."
        s["indices"] = f"S&P 500 tracker {_f(ix['SPY']['change_pct'])}%, Dow {_f(ix['DIA']['change_pct'])}%, small caps {_f(ix['IWM']['change_pct'])}%. The VIX sits at {_f(ix['VIX']['last'])}."
        ev = payload["economic_calendar"]
        s["macro"] = "Today's data: " + "; ".join(f"{e['event']}, expected {_f(e['estimate'])}" for e in ev[:2]) + "." if ev else "No major economic data today."
        er = payload["earnings_today"]
        s["earnings"] = " ".join(f"{e['symbol']} reports, options price a {_f(e['implied']['implied_move_pct'])}% move against a usual {_f(e['history']['avg_move_pct'])}%." for e in er[:3]) or "No major earnings today."
        s["news"] = "Also moving: " + "; ".join(n["title"] for n in payload["news"][:2]) + "."
        news = [n["title"] for n in payload["news"][:3]]
        title = f"Market open brief {payload['date']}"
    elif show == "weekly":
        b = sorted(payload["earnings"], key=lambda r: -r["implied"]["implied_move_pct"])
        top = b[0]
        s["hook"] = f"Options price a {_f(top['implied']['implied_move_pct'])}% earnings move in {top['symbol']} next week."
        s["board"] = f"Here are next week's biggest reporters, with what options price in against their usual move."
        rich = [r for r in b if r["verdict"] == "rich"][:2]
        cheap = [r for r in b if r["verdict"] == "cheap"][:1]
        s["standouts"] = " ".join(f"{r['symbol']} is pricing {_f(r['implied']['implied_move_pct'])}% against a usual {_f(r['history']['avg_move_pct'])}%." for r in rich + cheap)
        ev = payload["economic_calendar"]
        s["macro"] = "Also on the calendar: " + ", ".join(e["event"] for e in ev[:3]) + "." if ev else "A quiet week for economic data."
        news, title = [], f"Earnings week ahead: implied moves {payload['week_start']}"
    elif show == "radar":
        u = payload["unusual"]
        s["hook"] = f"Someone paid ${_f(u[0]['premium_usd'] / 1e6)} million for {u[0]['symbol']} {u[0]['option_type']}s today."
        for i, c in enumerate(u[:3], 1):
            s[f"contract_{i}"] = (f"{c['symbol']} {_f(c['strike'])} {c['option_type']}s, {c['dte']} days out. Volume {c['volume']:,} against open interest of {c['open_interest']:,}. "
                                  f"Break-even at {_f(c['breakeven'], 2)} versus a share price of {_f(c['spot'], 2)}.")
        news, title = [], f"Unusual options activity {payload['date']}"
    elif show == "alert":
        q, sym = payload.get("quote") or {}, payload.get("symbol")
        hl = payload.get("headlines", [])
        if sym:
            d = "down" if q["change_pct"] < 0 else "up"
            s["hook"] = f"{sym} is {d} {_f(abs(q['change_pct']))}% today."
            s["move"] = f"Shares at {_f(q['last'], 2)}, {d} {_f(abs(q['change_pct']))}% on the day."
        else:
            s["hook"] = "Breaking: " + (hl[0]["title"] if hl else "markets on the move") + "."
            s["move"] = "Here's how the main US index trackers are trading."
        s["why"] = ("Reports say: " + hl[0]["title"] + ".") if hl else "No confirmed news reason yet."
        x = (payload.get("x_chatter") or {}).get("summary", "")
        s["chatter"] = ("Chatter on X, unverified: " + x) if x else ""
        news = [h["title"] for h in hl[:3]]
        title = f"{sym + ' ' if sym else ''}breaking {payload['detected_at'][:10]}"
    elif show == "reaction":
        rs = payload["results"]
        if rs:
            r = rs[0]
            d = "up" if (r.get("move_pct") or 0) >= 0 else "down"
            s["hook"] = f"{r['symbol']} is {d} {_f(abs(r['move_pct']))}% after earnings" + \
                (f", options priced {_f(r['implied_move_pct'])}%." if r.get("implied_move_pct") else ".")
            s["results"] = " ".join(f"{x['symbol']} {'beat' if (x.get('eps_surprise_pct') or 0) >= 0 else 'missed'} on earnings per share by {_f(abs(x['eps_surprise_pct']))}%."
                                    for x in rs[:3] if x.get("eps_surprise_pct") is not None)
            s["moves"] = " ".join(f"{x['symbol']} moved {_f(abs(x['move_pct']))}%" + (f" against {_f(x['implied_move_pct'])}% implied." if x.get("implied_move_pct") else ".")
                                  for x in rs[:3] if x.get("move_pct") is not None)
        else:
            s["hook"], s["results"], s["moves"] = "No major reports last session.", "", ""
        news, title = [], f"Earnings reaction {payload['date']}"
    elif show == "sector":
        sm = payload["summary"]
        vs = sm.get("vs_history_pct")
        s["hook"] = f"{payload['sector']} trade at {_f(sm.get('median_pe_ttm') or 0)} times earnings" + \
            (f", {abs(vs)}% {'above' if vs >= 0 else 'below'} their 5-year norm." if vs is not None else ".")
        s["valuation"] = f"Median trailing P/E is {_f(sm.get('median_pe_ttm') or 0)}, against a 5-year median of {_f(sm.get('median_hist_pe') or 0)}."
        st = [x for x in payload["stocks"] if x.get("vs_history_pct") is not None]
        hi = max(st, key=lambda x: x["vs_history_pct"]) if st else None
        lo = min(st, key=lambda x: x["vs_history_pct"]) if st else None
        s["standouts"] = (f"Furthest above its own history: {hi['symbol']}, {hi['vs_history_pct']}%. "
                          f"Furthest below: {lo['symbol']}, {abs(lo['vs_history_pct'])}%.") if hi and lo else ""
        news, title = [], f"{payload['sector']} health check {payload['date']}"
    elif show == "dividends":
        t = payload["top"]
        s["hook"] = f"{t[0]['symbol']} tops our dividend cover score this fortnight at {t[0]['cover_score']} out of 100." if t else "Dividend scorecard."
        s["scorecard"] = " ".join(f"{x['symbol']}, yield {_f(x['yield_pct'])}%, score {x['cover_score']}." for x in t[:3])
        w = payload["weakest"]
        s["watch"] = ("Thinnest cover: " + ", ".join(f"{x['symbol']} at {x['cover_score']}" for x in w) + ".") if w else ""
        news, title = [], f"Dividend Kings cover scorecard {payload['date']}"
    elif show == "rotation":
        L, G = payload["leaders"], payload["laggards"]
        s["hook"] = f"{L[0]['label']} beat the S&P 500 by {_f(L[0]['rel_m1'])} points this month." if L else "Sector rotation check."
        s["leaders"] = "Leading over a month: " + ", ".join(f"{x['label']} {_f(x['rel_m1'])}" for x in L) + " points versus the index."
        s["laggards"] = "Lagging: " + ", ".join(f"{x['label']} {_f(x['rel_m1'])}" for x in G) + " points."
        news, title = [], f"Theme rotation {payload['date']}"
    else:
        ix, er = payload["index_week_pct"], payload["earnings_results"]
        s["hook"] = f"{er[0]['symbol']} moved {_f(er[0]['actual_move_pct'])}% on earnings this week." if er else "Here's your week in markets."
        s["indices"] = f"For the week: S&P 500 tracker {_f(ix.get('SPY', 0), 2)}%, Nasdaq tracker {_f(ix.get('QQQ', 0), 2)}%."
        s["earnings"] = " ".join(f"{r['symbol']} moved {_f(r['actual_move_pct'])}%" + (f" against {_f(r['implied_move_pct'])}% implied." if r.get("implied_move_pct") else ".") for r in er[:3])
        news, title = [], f"The week in 60 seconds {payload['week_of']}"
    s["outro"] = "Follow for the next one."
    return {"title": title, "caption": f"{title}. Not financial advice.", "hashtags": ["stocks", "investing", "earnings", "options", "markets"],
            "news_headlines": news, "sections": s}


def write(payload: dict, cfg: dict) -> dict:
    provider = cfg["writer"].get("provider", "anthropic")
    if payload.get("demo") and provider != "template" and not (secret("ANTHROPIC_API_KEY") or secret("XAI_API_KEY")):
        provider = "template"
    if provider == "template":
        out = template(payload)
    else:
        system, user = _prompt(payload)
        try:
            out = (_xai if provider == "xai" else _anthropic)(system, user, cfg)
        except Exception as exc:  # never fail the run: fall back and flag it
            out = template(payload)
            out["writer_error"] = str(exc)
    missing = [k for k in SECTIONS[payload["show"]] if not out.get("sections", {}).get(k)]
    for k in missing:
        out.setdefault("sections", {})[k] = ""
    out["show"] = payload["show"]
    return out


def script_text(script: dict) -> str:
    return " ".join([script.get("title", ""), script.get("caption", "")] + script.get("news_headlines", []) +
                    list(script.get("sections", {}).values()))
