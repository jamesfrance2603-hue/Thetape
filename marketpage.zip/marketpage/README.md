# MarketPage

Automated, data-led finance shorts for TikTok and YouTube Shorts. Four shows:

| Command | Show | Schedule (UK) |
| --- | --- | --- |
| `python run.py daily` | Market Open Brief: indices, today's macro data, today's earnings with implied moves, top news | Mon to Fri |
| `python run.py weekly` | Earnings Week Ahead: next week's reporters, options-implied move vs average past move | Sunday |
| `python run.py radar` | Options Radar: biggest unusual options trades | Tue, Thu |
| `python run.py recap` | Week in 60 Seconds: index moves, reporters vs their implied move | Friday |
| `python run.py watch` | Breaking alerts: big movers and market-moving headlines, with Grok summarising X chatter | Every 5 min, 09:00 to 21:15 weekdays |

Each run: **data → script → compliance check → render → Telegram approval → post.**

## Try it now (no keys needed)

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt          # plus ffmpeg on the system
python run.py weekly --demo
open out/*-weekly-demo/video.mp4
```

Demo mode uses invented sample numbers and can never be published.

## Go live

1. Copy `.env.example` to `.env` and add keys:
   - **Tradier** (quotes, options chains, history). Free with a Tradier brokerage account.
   - **Finnhub** (earnings calendar, news). Free tier works.
   - **FMP** (economic calendar). Starter plan.
   - **Anthropic** or **xAI** (script writing). Set `writer.provider` in `config.yaml`.
   - **ElevenLabs** (voice), or set `voice.provider: file` and drop your own `vo_<section>.mp3` recordings in the run folder.
   - **YouTube Data API** OAuth client + refresh token; **TikTok Content Posting API** token (app must pass TikTok's audit to post publicly).
   - **Telegram** bot token + your chat id for approvals.
2. Edit `config.yaml`: brand name, handle, colours, `universe.txt` for the stocks you cover.
3. Run one live show by hand: `python run.py weekly`. Check the video on your phone in Telegram.
4. Deploy to a small Linux server (any £5/month VPS): copy to `/opt/marketpage`, install `deploy/crontab.txt`
   and the two services in `deploy/` (Telegram listener and breaking-news watcher).
5. Reply `/approve <run_id>` in Telegram to post, `/reject <run_id>` to bin it.

## Safety rails built in

- **Numbers come from data, never from the model.** Charts and tables are drawn from the payload.
  `compliance.py` checks every figure in the script against the payload and flags any it can't find.
- **No advice wording.** Phrases like "you should buy", "price target", "guaranteed" are flagged.
- **AI disclosure set automatically:** `containsSyntheticMedia` on YouTube, `is_aigc` on TikTok.
- **Human approval by default.** `publish.auto_publish: false`. Keep it that way until you've approved a few weeks of clean drafts.
- If the AI call fails, a plain template script is used and the draft is flagged.

## Files

```
run.py                  CLI and orchestration
config.yaml             brand, providers, thresholds, schedule-related settings
universe.txt            stocks the page covers
marketpage/providers.py Tradier, Finnhub, FMP, RSS clients
marketpage/datasets.py  builds each show's data payload
marketpage/analytics.py implied move, historical earnings move, unusual options maths
marketpage/writer.py    Claude / Grok / template script writer
marketpage/compliance.py advice wording + number verification
marketpage/render.py    1080x1920 frames, charts, voice, ffmpeg
marketpage/publish.py   YouTube, TikTok, Telegram approval, optional HeyGen avatar
tests/                  pytest for the maths and compliance check
```

## Notes

- Check each API's current docs before going live; endpoints and field names change.
- Data licensing: Tradier/Finnhub free tiers are for personal use; check their terms for public display, or upgrade.
- Rewrite news in your own words (the writer does). Never show article text or other broadcasters' footage.

## Look and feel

`theme: trading_floor` (default) gives an 80s/90s trading-floor look: green-phosphor terminal type (VT323 and
IBM Plex Mono, both open licence, in `assets/fonts`), amber accents, CRT scanlines and glow, and a ticker tape
that scrolls across the top of every video using the stocks in that show. `theme: modern` is a clean dark style.
All visuals are drawn by `render.py` from the data; there is no designer or image generator in the loop.
