from datetime import date

from marketpage import analytics as A
from marketpage import compliance


def test_event_expiry_respects_session():
    exp = ["2026-11-06", "2026-11-13"]
    assert A.pick_event_expiry(exp, "2026-11-06", "bmo") == "2026-11-06"
    assert A.pick_event_expiry(exp, "2026-11-06", "amc") == "2026-11-13"


def test_atm_straddle():
    chain = [{"strike": 100, "option_type": "call", "bid": 4.9, "ask": 5.1},
             {"strike": 100, "option_type": "put", "bid": 4.4, "ask": 4.6},
             {"strike": 105, "option_type": "call", "bid": 2.0, "ask": 2.2}]
    st = A.atm_straddle(chain, 101.0)
    assert st["straddle"] == 9.5 and st["implied_move_pct"] == 9.4


def test_reaction_bmo_and_amc():
    closes = {"2026-10-27": 100.0, "2026-10-28": 110.0, "2026-10-29": 99.0}
    assert A.earnings_reaction_pct(closes, "2026-10-28", "bmo") == 10.0
    assert A.earnings_reaction_pct(closes, "2026-10-28", "amc") == 10.0


def test_unusual_filters():
    chain = [{"underlying": "X", "strike": 110, "option_type": "call", "bid": 1.9, "ask": 2.1, "volume": 5000, "open_interest": 500},
             {"underlying": "X", "strike": 90, "option_type": "put", "bid": 0.1, "ask": 0.2, "volume": 5000, "open_interest": 100}]
    hits = A.unusual_activity(chain, 100.0, "2026-11-20", date(2026, 11, 1), 1000, 3.0, 250000)
    assert len(hits) == 1 and hits[0]["breakeven"] == 112.0


def test_compliance_catches_invented_numbers_and_advice():
    payload = {"x": {"implied_move_pct": 7.9}}
    good = {"title": "NVDA", "sections": {"a": "Options price a 7.9% move in the S&P 500 giant."}}
    bad = {"title": "NVDA", "sections": {"a": "You should buy now, options price a 12.4% move."}}
    assert compliance.check(good, payload)["clean"]
    r = compliance.check(bad, payload)
    assert r["advice_flags"] and "12.4%" in r["unverified_numbers"]


def test_movers_threshold_and_realert():
    from marketpage import alerts
    a = {"mega_caps": ["NVDA"], "mega_cap_move_pct": 4.0, "move_pct": 7.0, "min_price": 5, "re_alert_step_pct": 5.0}
    st = {"symbols": {"AMD": -8.0}, "headlines": [], "sent": []}
    q = {"NVDA": {"last": 180, "change_pct": -4.5}, "SOFI": {"last": 20, "change_pct": 6.0},
         "AMD": {"last": 230, "change_pct": -9.0}, "PENNY": {"last": 2, "change_pct": 30.0}}
    assert [h["symbol"] for h in alerts.find_movers(q, a, st)] == ["NVDA"]


def test_x_chatter_numbers_never_count_as_facts():
    payload = {"quote": {"change_pct": -14.6}, "x_chatter": {"summary": "guidance cut to 2.1bn"}}
    script = {"sections": {"a": "Down 14.6%. Posts claim guidance of 2.1 billion."}}
    assert "2.1" in compliance.check(script, payload)["unverified_numbers"]


def test_cover_score_bounds():
    from marketpage.fundamentals import cover_score
    strong = {"fcf_payout_pct": 40, "payout_pct": 40, "net_debt_ebitda": 1.0, "div_cagr_5y_pct": 8}
    weak = {"fcf_payout_pct": 120, "payout_pct": 110, "net_debt_ebitda": 5, "div_cagr_5y_pct": 0}
    assert cover_score(strong) == 100 and cover_score(weak) == 0


def test_returns_from_closes():
    from datetime import date
    from marketpage.fundamentals import returns_from_closes
    closes = {"2026-08-01": 100.0, "2026-10-01": 110.0, "2026-10-25": 118.0, "2026-11-01": 121.0}
    r = returns_from_closes(closes, date(2026, 11, 1))
    assert r["w1"] == 2.5 and r["m1"] == 10.0 and r["m3"] == 21.0


def test_earnings_swing_alert():
    from marketpage import alerts
    a = {"mega_caps": [], "mega_cap_move_pct": 4.0, "move_pct": 7.0, "min_price": 5, "re_alert_step_pct": 5.0,
         "earnings_swing_ratio": 1.3}
    st = {"symbols": {}, "headlines": [], "sent": []}
    hits = alerts.find_movers({"UBER": {"last": 90, "change_pct": -6.0}}, a, st, {"UBER": 4.0})
    assert hits and hits[0]["earnings_swing"]


def test_marketdata_columns_to_contracts():
    from marketpage.providers import MarketData
    d = {"s": "ok", "underlying": ["AAPL", "AAPL"], "strike": [230, 230], "side": ["call", "put"],
         "expiration": [1794873600, 1794873600], "bid": [4.9, 4.4], "ask": [5.1, 4.6], "last": [5.0, 4.5],
         "volume": [1200, 900], "openInterest": [300, 5000], "iv": [0.41, 0.43]}
    rows = MarketData._contracts(MarketData.__new__(MarketData), d)
    assert rows[0]["option_type"] == "call" and rows[1]["open_interest"] == 5000
    assert rows[0]["expiration"] == "2026-11-17"
    from marketpage import analytics as A
    assert A.atm_straddle(rows, 231.0)["straddle"] == 9.5


def test_straddle_rejects_stale_quotes():
    # the weekend NVDA case: call 3.00 / put 8.62 at 187.5 with spot 186.64 breaks put-call parity
    chain = [{"strike": 187.5, "option_type": "call", "bid": 2.0, "ask": 4.0},
             {"strike": 187.5, "option_type": "put", "bid": 0.1, "ask": 17.14}]
    assert A.atm_straddle(chain, 186.64) is None
